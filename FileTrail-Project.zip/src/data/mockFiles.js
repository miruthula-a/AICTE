// AICTE Approval Workflow & Compliance Monitoring - Master Registry Data
import { CAMPUS_PLACEHOLDER_SVG, BLUEPRINT_PLACEHOLDER_SVG } from '../lib/placeholders';

export const STAGES = [
  {
    id: 1,
    key: "STAGE_01_SUBMISSION",
    code: "01",
    name: "Application Inward",
    shortName: "Inward & Fee",
    pigeonholeRack: "Rack 01-A",
    leadTimeDays: 7,
    description: "Initial application inward entry, processing fee verification & affidavit receipt."
  },
  {
    id: 2,
    key: "STAGE_02_DOC_SCRUTINY",
    code: "02",
    name: "Document Scrutiny",
    shortName: "Doc Scrutiny",
    pigeonholeRack: "Rack 02-B",
    leadTimeDays: 14,
    description: "Scrutiny committee verifies land title, Fire NOC, cadre ratios & statutory building plans."
  },
  {
    id: 3,
    key: "STAGE_03_EVC_VISIT",
    code: "03",
    name: "Expert Visiting Committee",
    shortName: "EVC Inspection",
    pigeonholeRack: "Rack 03-C",
    leadTimeDays: 15,
    description: "Physical inspection of campus laboratories, barrier-free access, computing centers & equipment."
  },
  {
    id: 4,
    key: "STAGE_04_SHC_REVIEW",
    code: "04",
    name: "Standing Hearing Committee",
    shortName: "SHC Hearing",
    pigeonholeRack: "Rack 04-D",
    leadTimeDays: 10,
    description: "Appellate hearing of flagged deficiencies, review of institution rejoinder & compliance submissions."
  },
  {
    id: 5,
    key: "STAGE_05_DECISION",
    code: "05",
    name: "Executive Committee Order",
    shortName: "Executive Committee",
    pigeonholeRack: "Rack 05-E",
    leadTimeDays: 5,
    description: "Final statutory decision recommendation and draft order formulation for Executive Committee."
  }
];

export const REGIONS = [
  { code: "ALL", name: "All Regions", city: "National HQ", coverage: "All 8 Regional Offices across India" },
  { code: "WRO", name: "Western Region", city: "Mumbai", coverage: "Maharashtra, Goa" },
  { code: "NRO", name: "Northern Region", city: "Kanpur", coverage: "Uttar Pradesh, Uttarakhand" },
  { code: "SRO", name: "Southern Region", city: "Chennai", coverage: "Tamil Nadu, Puducherry" },
  { code: "NWRO", name: "North-Western Region", city: "Chandigarh", coverage: "Delhi, Punjab, Haryana, HP, J&K" },
  { code: "SCRO", name: "South-Central Region", city: "Hyderabad", coverage: "Telangana, Andhra Pradesh" },
  { code: "ERO", name: "Eastern Region", city: "Kolkata", coverage: "West Bengal, Odisha, Bihar, Jharkhand, Assam & NE" },
  { code: "CRO", name: "Central Region", city: "Bhopal", coverage: "Madhya Pradesh, Gujarat, Chhattisgarh" },
  { code: "SWRO", name: "South-Western Region", city: "Bengaluru", coverage: "Karnataka, Kerala" }
];

export const INITIAL_FILES = [
  {
    "id": "FILE-2026-9041",
    "fileNumber": "AICTE/WRO/2026-27/1-4921098",
    "instituteName": "Saraswati College of Engineering",
    "location": "Navi Mumbai, Maharashtra",
    "region": "WRO",
    "intake": 360,
    "complianceScore": 60,
    "currentStageId": 2,
    "daysElapsed": 12,
    "totalSlaDays": 14,
    "status": "COMPLIANCE_GAP",
    "statusText": "Fire NOC Expired",
    "photoUrl": CAMPUS_PLACEHOLDER_SVG,
    "labPhotoUrl": "https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?auto=format&fit=crop&w=1200&q=85",
    "blueprintUrl": BLUEPRINT_PLACEHOLDER_SVG,
    "geoCoords": "19.047° N, 73.069° E",
    "labDetails": "Advanced Embedded Systems & IoT Lab (60 Workstations)",
    "officer": {
      "name": "Smt. Archana Varma",
      "role": "Scrutiny Officer",
      "avatar": "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=150&q=80"
    },
    "metrics": {
      "carpetArea": {
        "verified": 4820,
        "required": 4200,
        "unit": "sq.m",
        "ok": true
      },
      "fsr": {
        "actual": "1:17.2",
        "required": "1:15",
        "ok": false
      },
      "fireNoc": {
        "validUntil": "18 Jan 2026",
        "ok": false,
        "label": "Expired 12d ago"
      },
      "landTitle": {
        "registered": true,
        "ok": true,
        "label": "30-Yr Lease Deed Verified"
      },
      "jointFdr": {
        "amount": "₹1.00 Crore",
        "ok": true,
        "label": "Bank of India Joint FDR"
      }
    },
    "statusColor": "vermilion",
    "stampLabel": "COMPLIANCE GAP",
    "auditTrail": [
      {
        "id": "AUDIT-FILE-2026-9041-01",
        "fileId": "FILE-2026-9041",
        "timestamp": "2026-01-20T09:30:00.000Z",
        "dateFormatted": "20 Jan 2026",
        "timeFormatted": "09:30",
        "officer": "Smt. Archana Varma",
        "action": "APPLICATION_INWARD",
        "remark": "Application inward received, processing fees verified, uploaded affidavit registered.",
        "prevHash": "GENESIS_BLOCK_AICTE_REGULATORY_ROOT",
        "hash": "sha256:0a4f89b1c720e3d5"
      },
      {
        "id": "AUDIT-FILE-2026-9041-02",
        "fileId": "FILE-2026-9041",
        "timestamp": "2026-01-28T14:15:00.000Z",
        "dateFormatted": "28 Jan 2026",
        "timeFormatted": "14:15",
        "officer": "Smt. Archana Varma",
        "action": "STAGE_ADVANCE",
        "remark": "Docket moved to Document Scrutiny table. Cross-referencing revenue title and Fire NOC.",
        "prevHash": "sha256:0a4f89b1c720e3d5",
        "hash": "sha256:4b91f0c2e819a374"
      },
      {
        "id": "AUDIT-FILE-2026-9041-03",
        "fileId": "FILE-2026-9041",
        "timestamp": "2026-02-05T11:00:00.000Z",
        "dateFormatted": "05 Feb 2026",
        "timeFormatted": "11:00",
        "officer": "Smt. Archana Varma",
        "action": "DEFICIENCY_NOTED",
        "remark": "Statutory deficiency recorded: Fire NOC Expired. Show-cause memo issued.",
        "prevHash": "sha256:4b91f0c2e819a374",
        "hash": "sha256:8f21e09bc471a288"
      }
    ]
  },
  {
    "id": "FILE-2026-9042",
    "fileNumber": "AICTE/WRO/2026-27/1-4921105",
    "instituteName": "Veermata Jijabai Technological Institute (VJTI)",
    "location": "Matunga, Mumbai, Maharashtra",
    "region": "WRO",
    "intake": 680,
    "complianceScore": 100,
    "currentStageId": 5,
    "daysElapsed": 48,
    "totalSlaDays": 50,
    "status": "ON_TRACK",
    "statusText": "Final LoA Approved",
    "photoUrl": CAMPUS_PLACEHOLDER_SVG,
    "labPhotoUrl": "https://images.unsplash.com/photo-1581092335397-9583fe92d232?auto=format&fit=crop&w=1200&q=85",
    "blueprintUrl": BLUEPRINT_PLACEHOLDER_SVG,
    "geoCoords": "19.022° N, 72.856° E",
    "labDetails": "National High Voltage & Power Systems Testing Grid",
    "officer": {
      "name": "Dr. Ramesh S. Kulkarni",
      "role": "Regional Director",
      "avatar": "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=150&q=80"
    },
    "metrics": {
      "carpetArea": {
        "verified": 9400,
        "required": 6800,
        "unit": "sq.m",
        "ok": true
      },
      "fsr": {
        "actual": "1:13.2",
        "required": "1:15",
        "ok": true
      },
      "fireNoc": {
        "validUntil": "25 Oct 2027",
        "ok": true,
        "label": "Mumbai Fire Brigade NOC"
      },
      "landTitle": {
        "registered": true,
        "ok": true,
        "label": "Autonomous Govt Freehold"
      },
      "jointFdr": {
        "amount": "₹1.50 Crore",
        "ok": true,
        "label": "State Bank of India FDR"
      }
    },
    "statusColor": "pine",
    "stampLabel": "COUNCIL ORDER",
    "auditTrail": [
      {
        "id": "AUDIT-FILE-2026-9042-01",
        "fileId": "FILE-2026-9042",
        "timestamp": "2026-01-20T09:30:00.000Z",
        "dateFormatted": "20 Jan 2026",
        "timeFormatted": "09:30",
        "officer": "Dr. Ramesh S. Kulkarni",
        "action": "APPLICATION_INWARD",
        "remark": "Application inward received, processing fees verified, uploaded affidavit registered.",
        "prevHash": "GENESIS_BLOCK_AICTE_REGULATORY_ROOT",
        "hash": "sha256:0a4f89b1c720e3d5"
      },
      {
        "id": "AUDIT-FILE-2026-9042-02",
        "fileId": "FILE-2026-9042",
        "timestamp": "2026-01-28T14:15:00.000Z",
        "dateFormatted": "28 Jan 2026",
        "timeFormatted": "14:15",
        "officer": "Dr. Ramesh S. Kulkarni",
        "action": "STAGE_ADVANCE",
        "remark": "Docket moved to Document Scrutiny table. Cross-referencing revenue title and Fire NOC.",
        "prevHash": "sha256:0a4f89b1c720e3d5",
        "hash": "sha256:4b91f0c2e819a374"
      }
    ]
  },
  {
    "id": "FILE-2026-9043",
    "fileNumber": "AICTE/WRO/2026-27/1-4921189",
    "instituteName": "COEP Technological University",
    "location": "Shivajinagar, Pune, Maharashtra",
    "region": "WRO",
    "intake": 720,
    "complianceScore": 100,
    "currentStageId": 3,
    "daysElapsed": 27,
    "totalSlaDays": 30,
    "status": "DUE_SOON",
    "statusText": "EVC Visit in 2 Days",
    "photoUrl": CAMPUS_PLACEHOLDER_SVG,
    "labPhotoUrl": "https://images.unsplash.com/photo-1581092160607-ee22621dd758?auto=format&fit=crop&w=1200&q=85",
    "blueprintUrl": BLUEPRINT_PLACEHOLDER_SVG,
    "geoCoords": "18.529° N, 73.856° E",
    "labDetails": "FabLab & Precision Mechatronics Design Center",
    "officer": {
      "name": "Prof. Dilip G. Rao",
      "role": "EVC Field Convener",
      "avatar": "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&w=150&q=80"
    },
    "metrics": {
      "carpetArea": {
        "verified": 10500,
        "required": 7200,
        "unit": "sq.m",
        "ok": true
      },
      "fsr": {
        "actual": "1:14.0",
        "required": "1:15",
        "ok": true
      },
      "fireNoc": {
        "validUntil": "19 Aug 2026",
        "ok": true,
        "label": "PMC Fire Department NOC"
      },
      "landTitle": {
        "registered": true,
        "ok": true,
        "label": "Heritage Campus Freehold Title"
      },
      "jointFdr": {
        "amount": "₹1.50 Crore",
        "ok": true,
        "label": "Bank of Maharashtra FDR"
      }
    },
    "statusColor": "ochre",
    "stampLabel": "IN SCRUTINY",
    "auditTrail": [
      {
        "id": "AUDIT-FILE-2026-9043-01",
        "fileId": "FILE-2026-9043",
        "timestamp": "2026-01-20T09:30:00.000Z",
        "dateFormatted": "20 Jan 2026",
        "timeFormatted": "09:30",
        "officer": "Prof. Dilip G. Rao",
        "action": "APPLICATION_INWARD",
        "remark": "Application inward received, processing fees verified, uploaded affidavit registered.",
        "prevHash": "GENESIS_BLOCK_AICTE_REGULATORY_ROOT",
        "hash": "sha256:0a4f89b1c720e3d5"
      },
      {
        "id": "AUDIT-FILE-2026-9043-02",
        "fileId": "FILE-2026-9043",
        "timestamp": "2026-01-28T14:15:00.000Z",
        "dateFormatted": "28 Jan 2026",
        "timeFormatted": "14:15",
        "officer": "Prof. Dilip G. Rao",
        "action": "STAGE_ADVANCE",
        "remark": "Docket moved to Document Scrutiny table. Cross-referencing revenue title and Fire NOC.",
        "prevHash": "sha256:0a4f89b1c720e3d5",
        "hash": "sha256:4b91f0c2e819a374"
      }
    ]
  },
  {
    "id": "FILE-2026-8812",
    "fileNumber": "AICTE/NRO/2026-27/1-3829014",
    "instituteName": "Awadh Institute of Technology",
    "location": "Lucknow, Uttar Pradesh",
    "region": "NRO",
    "intake": 420,
    "complianceScore": 100,
    "currentStageId": 3,
    "daysElapsed": 28,
    "totalSlaDays": 35,
    "status": "DUE_SOON",
    "statusText": "EVC Closes in 3 Days",
    "photoUrl": CAMPUS_PLACEHOLDER_SVG,
    "labPhotoUrl": "https://images.unsplash.com/photo-1581092580497-e0d23cbdf1dc?auto=format&fit=crop&w=1200&q=85",
    "blueprintUrl": BLUEPRINT_PLACEHOLDER_SVG,
    "geoCoords": "26.846° N, 80.946° E",
    "labDetails": "Heavy Civil Structures & Concrete Testing Lab",
    "officer": {
      "name": "Prof. D. K. Sharma",
      "role": "EVC Convener",
      "avatar": "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=150&q=80"
    },
    "metrics": {
      "carpetArea": {
        "verified": 4890,
        "required": 4200,
        "unit": "sq.m",
        "ok": true
      },
      "fsr": {
        "actual": "1:14.5",
        "required": "1:15",
        "ok": true
      },
      "fireNoc": {
        "validUntil": "14 Dec 2026",
        "ok": true,
        "label": "Valid & Active"
      },
      "landTitle": {
        "registered": true,
        "ok": true,
        "label": "Clear Title (7.5 Acres)"
      },
      "jointFdr": {
        "amount": "₹1.00 Crore",
        "ok": true,
        "label": "PNB Joint FDR Active"
      }
    },
    "statusColor": "ochre",
    "stampLabel": "IN SCRUTINY",
    "auditTrail": [
      {
        "id": "AUDIT-FILE-2026-8812-01",
        "fileId": "FILE-2026-8812",
        "timestamp": "2026-01-20T09:30:00.000Z",
        "dateFormatted": "20 Jan 2026",
        "timeFormatted": "09:30",
        "officer": "Prof. D. K. Sharma",
        "action": "APPLICATION_INWARD",
        "remark": "Application inward received, processing fees verified, uploaded affidavit registered.",
        "prevHash": "GENESIS_BLOCK_AICTE_REGULATORY_ROOT",
        "hash": "sha256:0a4f89b1c720e3d5"
      },
      {
        "id": "AUDIT-FILE-2026-8812-02",
        "fileId": "FILE-2026-8812",
        "timestamp": "2026-01-28T14:15:00.000Z",
        "dateFormatted": "28 Jan 2026",
        "timeFormatted": "14:15",
        "officer": "Prof. D. K. Sharma",
        "action": "STAGE_ADVANCE",
        "remark": "Docket moved to Document Scrutiny table. Cross-referencing revenue title and Fire NOC.",
        "prevHash": "sha256:0a4f89b1c720e3d5",
        "hash": "sha256:4b91f0c2e819a374"
      }
    ]
  },
  {
    "id": "FILE-2026-8813",
    "fileNumber": "AICTE/NRO/2026-27/1-3829099",
    "instituteName": "Harcourt Butler Technical University (HBTU)",
    "location": "Nawabganj, Kanpur, Uttar Pradesh",
    "region": "NRO",
    "intake": 540,
    "complianceScore": 100,
    "currentStageId": 1,
    "daysElapsed": 2,
    "totalSlaDays": 7,
    "status": "ON_TRACK",
    "statusText": "Fee Reconciled",
    "photoUrl": CAMPUS_PLACEHOLDER_SVG,
    "labPhotoUrl": "https://images.unsplash.com/photo-1532094349884-543bc11b234d?auto=format&fit=crop&w=1200&q=85",
    "blueprintUrl": BLUEPRINT_PLACEHOLDER_SVG,
    "geoCoords": "26.495° N, 80.312° E",
    "labDetails": "Chemical Engineering Pilot Plant & Bio-Process Suite",
    "officer": {
      "name": "Shri S. P. Shukla",
      "role": "Accounts Section Officer",
      "avatar": "https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?auto=format&fit=crop&w=150&q=80"
    },
    "metrics": {
      "carpetArea": {
        "verified": 8100,
        "required": 5200,
        "unit": "sq.m",
        "ok": true
      },
      "fsr": {
        "actual": "1:13.6",
        "required": "1:15",
        "ok": true
      },
      "fireNoc": {
        "validUntil": "11 Oct 2027",
        "ok": true,
        "label": "Kanpur Nagar Fire NOC"
      },
      "landTitle": {
        "registered": true,
        "ok": true,
        "label": "UP State Freehold Campus"
      },
      "jointFdr": {
        "amount": "₹1.20 Crore",
        "ok": true,
        "label": "Union Bank of India FDR"
      }
    },
    "statusColor": "pine",
    "stampLabel": "IN SCRUTINY",
    "auditTrail": [
      {
        "id": "AUDIT-FILE-2026-8813-01",
        "fileId": "FILE-2026-8813",
        "timestamp": "2026-01-20T09:30:00.000Z",
        "dateFormatted": "20 Jan 2026",
        "timeFormatted": "09:30",
        "officer": "Shri S. P. Shukla",
        "action": "APPLICATION_INWARD",
        "remark": "Application inward received, processing fees verified, uploaded affidavit registered.",
        "prevHash": "GENESIS_BLOCK_AICTE_REGULATORY_ROOT",
        "hash": "sha256:0a4f89b1c720e3d5"
      }
    ]
  },
  {
    "id": "FILE-2026-8814",
    "fileNumber": "AICTE/NRO/2026-27/1-3829210",
    "instituteName": "Graphic Era Institute of Technology",
    "location": "Clement Town, Dehradun, Uttarakhand",
    "region": "NRO",
    "intake": 480,
    "complianceScore": 60,
    "currentStageId": 4,
    "daysElapsed": 39,
    "totalSlaDays": 40,
    "status": "COMPLIANCE_GAP",
    "statusText": "Land Affidavit Pending",
    "photoUrl": CAMPUS_PLACEHOLDER_SVG,
    "labPhotoUrl": "https://images.unsplash.com/photo-1517694712202-14dd9538aa97?auto=format&fit=crop&w=1200&q=85",
    "blueprintUrl": BLUEPRINT_PLACEHOLDER_SVG,
    "geoCoords": "30.272° N, 78.006° E",
    "labDetails": "Artificial Intelligence & Big Data Analytics Center",
    "officer": {
      "name": "Smt. Neha Rawat",
      "role": "Standing Hearing Officer",
      "avatar": "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=150&q=80"
    },
    "metrics": {
      "carpetArea": {
        "verified": 5100,
        "required": 4800,
        "unit": "sq.m",
        "ok": true
      },
      "fsr": {
        "actual": "1:16.4",
        "required": "1:15",
        "ok": false
      },
      "fireNoc": {
        "validUntil": "05 Jun 2026",
        "ok": true,
        "label": "Uttarakhand Fire Service"
      },
      "landTitle": {
        "registered": false,
        "ok": false,
        "label": "Affidavit Form 104 Awaited"
      },
      "jointFdr": {
        "amount": "₹1.00 Crore",
        "ok": true,
        "label": "Punjab National Bank FDR"
      }
    },
    "statusColor": "vermilion",
    "stampLabel": "COMPLIANCE GAP",
    "auditTrail": [
      {
        "id": "AUDIT-FILE-2026-8814-01",
        "fileId": "FILE-2026-8814",
        "timestamp": "2026-01-20T09:30:00.000Z",
        "dateFormatted": "20 Jan 2026",
        "timeFormatted": "09:30",
        "officer": "Smt. Neha Rawat",
        "action": "APPLICATION_INWARD",
        "remark": "Application inward received, processing fees verified, uploaded affidavit registered.",
        "prevHash": "GENESIS_BLOCK_AICTE_REGULATORY_ROOT",
        "hash": "sha256:0a4f89b1c720e3d5"
      },
      {
        "id": "AUDIT-FILE-2026-8814-02",
        "fileId": "FILE-2026-8814",
        "timestamp": "2026-01-28T14:15:00.000Z",
        "dateFormatted": "28 Jan 2026",
        "timeFormatted": "14:15",
        "officer": "Smt. Neha Rawat",
        "action": "STAGE_ADVANCE",
        "remark": "Docket moved to Document Scrutiny table. Cross-referencing revenue title and Fire NOC.",
        "prevHash": "sha256:0a4f89b1c720e3d5",
        "hash": "sha256:4b91f0c2e819a374"
      },
      {
        "id": "AUDIT-FILE-2026-8814-03",
        "fileId": "FILE-2026-8814",
        "timestamp": "2026-02-05T11:00:00.000Z",
        "dateFormatted": "05 Feb 2026",
        "timeFormatted": "11:00",
        "officer": "Smt. Neha Rawat",
        "action": "DEFICIENCY_NOTED",
        "remark": "Statutory deficiency recorded: Land Affidavit Pending. Show-cause memo issued.",
        "prevHash": "sha256:4b91f0c2e819a374",
        "hash": "sha256:8f21e09bc471a288"
      }
    ]
  },
  {
    "id": "FILE-2026-7640",
    "fileNumber": "AICTE/SRO/2026-27/1-5019821",
    "instituteName": "Karpagam Institute of Technology",
    "location": "Coimbatore, Tamil Nadu",
    "region": "SRO",
    "intake": 540,
    "complianceScore": 100,
    "currentStageId": 1,
    "daysElapsed": 3,
    "totalSlaDays": 7,
    "status": "ON_TRACK",
    "statusText": "Fee Reconciled",
    "photoUrl": CAMPUS_PLACEHOLDER_SVG,
    "labPhotoUrl": "https://images.unsplash.com/photo-1581092162384-8987c1d64718?auto=format&fit=crop&w=1200&q=85",
    "blueprintUrl": BLUEPRINT_PLACEHOLDER_SVG,
    "geoCoords": "10.902° N, 76.994° E",
    "labDetails": "Advanced VLSI & Embedded Systems Laboratory",
    "officer": {
      "name": "Shri T. Natarajan",
      "role": "Section Officer",
      "avatar": "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=150&q=80"
    },
    "metrics": {
      "carpetArea": {
        "verified": 6200,
        "required": 4800,
        "unit": "sq.m",
        "ok": true
      },
      "fsr": {
        "actual": "1:13.8",
        "required": "1:15",
        "ok": true
      },
      "fireNoc": {
        "validUntil": "28 Nov 2026",
        "ok": true,
        "label": "TN Fire Service NOC"
      },
      "landTitle": {
        "registered": true,
        "ok": true,
        "label": "Clear Title (12.4 Acres)"
      },
      "jointFdr": {
        "amount": "₹1.00 Crore",
        "ok": true,
        "label": "IOB Joint FDR Active"
      }
    },
    "statusColor": "pine",
    "stampLabel": "IN SCRUTINY",
    "auditTrail": [
      {
        "id": "AUDIT-FILE-2026-7640-01",
        "fileId": "FILE-2026-7640",
        "timestamp": "2026-01-20T09:30:00.000Z",
        "dateFormatted": "20 Jan 2026",
        "timeFormatted": "09:30",
        "officer": "Shri T. Natarajan",
        "action": "APPLICATION_INWARD",
        "remark": "Application inward received, processing fees verified, uploaded affidavit registered.",
        "prevHash": "GENESIS_BLOCK_AICTE_REGULATORY_ROOT",
        "hash": "sha256:0a4f89b1c720e3d5"
      }
    ]
  },
  {
    "id": "FILE-2026-7641",
    "fileNumber": "AICTE/SRO/2026-27/1-5019912",
    "instituteName": "SSN College of Engineering",
    "location": "Kalavakkam, Chennai, Tamil Nadu",
    "region": "SRO",
    "intake": 750,
    "complianceScore": 100,
    "currentStageId": 5,
    "daysElapsed": 44,
    "totalSlaDays": 45,
    "status": "ON_TRACK",
    "statusText": "Council Order Issued",
    "photoUrl": CAMPUS_PLACEHOLDER_SVG,
    "labPhotoUrl": "https://images.unsplash.com/photo-1507668077129-56e32842fceb?auto=format&fit=crop&w=1200&q=85",
    "blueprintUrl": BLUEPRINT_PLACEHOLDER_SVG,
    "geoCoords": "12.752° N, 80.197° E",
    "labDetails": "Centre for Photonics & Quantum Information",
    "officer": {
      "name": "Dr. K. Venkataraman",
      "role": "Regional Officer",
      "avatar": "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=150&q=80"
    },
    "metrics": {
      "carpetArea": {
        "verified": 11200,
        "required": 7500,
        "unit": "sq.m",
        "ok": true
      },
      "fsr": {
        "actual": "1:12.1",
        "required": "1:15",
        "ok": true
      },
      "fireNoc": {
        "validUntil": "30 Dec 2027",
        "ok": true,
        "label": "TN Fire & Rescue Cleared"
      },
      "landTitle": {
        "registered": true,
        "ok": true,
        "label": "Freehold Title (250 Acres)"
      },
      "jointFdr": {
        "amount": "₹2.00 Crore",
        "ok": true,
        "label": "HDFC Joint FDR Active"
      }
    },
    "statusColor": "pine",
    "stampLabel": "COUNCIL ORDER",
    "auditTrail": [
      {
        "id": "AUDIT-FILE-2026-7641-01",
        "fileId": "FILE-2026-7641",
        "timestamp": "2026-01-20T09:30:00.000Z",
        "dateFormatted": "20 Jan 2026",
        "timeFormatted": "09:30",
        "officer": "Dr. K. Venkataraman",
        "action": "APPLICATION_INWARD",
        "remark": "Application inward received, processing fees verified, uploaded affidavit registered.",
        "prevHash": "GENESIS_BLOCK_AICTE_REGULATORY_ROOT",
        "hash": "sha256:0a4f89b1c720e3d5"
      },
      {
        "id": "AUDIT-FILE-2026-7641-02",
        "fileId": "FILE-2026-7641",
        "timestamp": "2026-01-28T14:15:00.000Z",
        "dateFormatted": "28 Jan 2026",
        "timeFormatted": "14:15",
        "officer": "Dr. K. Venkataraman",
        "action": "STAGE_ADVANCE",
        "remark": "Docket moved to Document Scrutiny table. Cross-referencing revenue title and Fire NOC.",
        "prevHash": "sha256:0a4f89b1c720e3d5",
        "hash": "sha256:4b91f0c2e819a374"
      }
    ]
  },
  {
    "id": "FILE-2026-7642",
    "fileNumber": "AICTE/SRO/2026-27/1-5019998",
    "instituteName": "Thiagarajar College of Engineering",
    "location": "Madurai, Tamil Nadu",
    "region": "SRO",
    "intake": 480,
    "complianceScore": 80,
    "currentStageId": 2,
    "daysElapsed": 17,
    "totalSlaDays": 14,
    "status": "OVERDUE",
    "statusText": "Scrutiny Overdue (+3 Days)",
    "photoUrl": CAMPUS_PLACEHOLDER_SVG,
    "labPhotoUrl": "https://images.unsplash.com/photo-1558494949-ef010cbdcc31?auto=format&fit=crop&w=1200&q=85",
    "blueprintUrl": BLUEPRINT_PLACEHOLDER_SVG,
    "geoCoords": "9.882° N, 78.081° E",
    "labDetails": "High-Performance Computing Cluster & Network Security",
    "officer": {
      "name": "Smt. Meenakshi Sundaram",
      "role": "Doc Auditor",
      "avatar": "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=150&q=80"
    },
    "metrics": {
      "carpetArea": {
        "verified": 6500,
        "required": 4800,
        "unit": "sq.m",
        "ok": true
      },
      "fsr": {
        "actual": "1:18.1",
        "required": "1:15",
        "ok": false
      },
      "fireNoc": {
        "validUntil": "02 Mar 2026",
        "ok": true,
        "label": "Madurai Fire Service NOC"
      },
      "landTitle": {
        "registered": true,
        "ok": true,
        "label": "Trust Registered Deed"
      },
      "jointFdr": {
        "amount": "₹1.00 Crore",
        "ok": true,
        "label": "Indian Bank FDR"
      }
    },
    "statusColor": "vermilion",
    "stampLabel": "URGENT OVERDUE",
    "auditTrail": [
      {
        "id": "AUDIT-FILE-2026-7642-01",
        "fileId": "FILE-2026-7642",
        "timestamp": "2026-01-20T09:30:00.000Z",
        "dateFormatted": "20 Jan 2026",
        "timeFormatted": "09:30",
        "officer": "Smt. Meenakshi Sundaram",
        "action": "APPLICATION_INWARD",
        "remark": "Application inward received, processing fees verified, uploaded affidavit registered.",
        "prevHash": "GENESIS_BLOCK_AICTE_REGULATORY_ROOT",
        "hash": "sha256:0a4f89b1c720e3d5"
      },
      {
        "id": "AUDIT-FILE-2026-7642-02",
        "fileId": "FILE-2026-7642",
        "timestamp": "2026-01-28T14:15:00.000Z",
        "dateFormatted": "28 Jan 2026",
        "timeFormatted": "14:15",
        "officer": "Smt. Meenakshi Sundaram",
        "action": "STAGE_ADVANCE",
        "remark": "Docket moved to Document Scrutiny table. Cross-referencing revenue title and Fire NOC.",
        "prevHash": "sha256:0a4f89b1c720e3d5",
        "hash": "sha256:4b91f0c2e819a374"
      }
    ]
  },
  {
    "id": "FILE-2026-7643",
    "fileNumber": "AICTE/SRO/2026-27/1-5020101",
    "instituteName": "PSG College of Technology",
    "location": "Peelamedu, Coimbatore, Tamil Nadu",
    "region": "SRO",
    "intake": 840,
    "complianceScore": 100,
    "currentStageId": 5,
    "daysElapsed": 44,
    "totalSlaDays": 45,
    "status": "ON_TRACK",
    "statusText": "Autonomous EoA Granted",
    "photoUrl": CAMPUS_PLACEHOLDER_SVG,
    "labPhotoUrl": "https://images.unsplash.com/photo-1581092160607-ee22621dd758?auto=format&fit=crop&w=1200&q=85",
    "blueprintUrl": BLUEPRINT_PLACEHOLDER_SVG,
    "geoCoords": "11.025° N, 76.992° E",
    "labDetails": "Robotics & Flexible Manufacturing Automation Centre",
    "officer": {
      "name": "Dr. K. Venkataraman",
      "role": "Regional Officer",
      "avatar": "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=150&q=80"
    },
    "metrics": {
      "carpetArea": {
        "verified": 12400,
        "required": 8000,
        "unit": "sq.m",
        "ok": true
      },
      "fsr": {
        "actual": "1:12.4",
        "required": "1:15",
        "ok": true
      },
      "fireNoc": {
        "validUntil": "15 Jan 2028",
        "ok": true,
        "label": "Coimbatore South Fire NOC"
      },
      "landTitle": {
        "registered": true,
        "ok": true,
        "label": "PSG & Sons Charities Deed"
      },
      "jointFdr": {
        "amount": "₹2.00 Crore",
        "ok": true,
        "label": "Central Bank of India FDR"
      }
    },
    "statusColor": "pine",
    "stampLabel": "COUNCIL ORDER",
    "auditTrail": [
      {
        "id": "AUDIT-FILE-2026-7643-01",
        "fileId": "FILE-2026-7643",
        "timestamp": "2026-01-20T09:30:00.000Z",
        "dateFormatted": "20 Jan 2026",
        "timeFormatted": "09:30",
        "officer": "Dr. K. Venkataraman",
        "action": "APPLICATION_INWARD",
        "remark": "Application inward received, processing fees verified, uploaded affidavit registered.",
        "prevHash": "GENESIS_BLOCK_AICTE_REGULATORY_ROOT",
        "hash": "sha256:0a4f89b1c720e3d5"
      },
      {
        "id": "AUDIT-FILE-2026-7643-02",
        "fileId": "FILE-2026-7643",
        "timestamp": "2026-01-28T14:15:00.000Z",
        "dateFormatted": "28 Jan 2026",
        "timeFormatted": "14:15",
        "officer": "Dr. K. Venkataraman",
        "action": "STAGE_ADVANCE",
        "remark": "Docket moved to Document Scrutiny table. Cross-referencing revenue title and Fire NOC.",
        "prevHash": "sha256:0a4f89b1c720e3d5",
        "hash": "sha256:4b91f0c2e819a374"
      }
    ]
  },
  {
    "id": "FILE-2026-7644",
    "fileNumber": "AICTE/SRO/2026-27/1-5020188",
    "instituteName": "College of Engineering, Guindy (CEG - Anna University)",
    "location": "Guindy, Chennai, Tamil Nadu",
    "region": "SRO",
    "intake": 900,
    "complianceScore": 100,
    "currentStageId": 5,
    "daysElapsed": 40,
    "totalSlaDays": 45,
    "status": "ON_TRACK",
    "statusText": "Council Order Issued",
    "photoUrl": CAMPUS_PLACEHOLDER_SVG,
    "labPhotoUrl": "https://images.unsplash.com/photo-1581092335397-9583fe92d232?auto=format&fit=crop&w=1200&q=85",
    "blueprintUrl": BLUEPRINT_PLACEHOLDER_SVG,
    "geoCoords": "13.011° N, 80.235° E",
    "labDetails": "National High Voltage & Quantum Materials Testing Lab",
    "officer": {
      "name": "Dr. K. Venkataraman",
      "role": "Regional Officer",
      "avatar": "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=150&q=80"
    },
    "metrics": {
      "carpetArea": {
        "verified": 15600,
        "required": 9000,
        "unit": "sq.m",
        "ok": true
      },
      "fsr": {
        "actual": "1:11.8",
        "required": "1:15",
        "ok": true
      },
      "fireNoc": {
        "validUntil": "20 Dec 2028",
        "ok": true,
        "label": "TN Fire & Rescue Cleared"
      },
      "landTitle": {
        "registered": true,
        "ok": true,
        "label": "State University Freehold Campus"
      },
      "jointFdr": {
        "amount": "₹2.50 Crore",
        "ok": true,
        "label": "State Bank of India FDR"
      }
    },
    "statusColor": "pine",
    "stampLabel": "COUNCIL ORDER",
    "auditTrail": [
      {
        "id": "AUDIT-FILE-2026-7644-01",
        "fileId": "FILE-2026-7644",
        "timestamp": "2026-01-20T09:30:00.000Z",
        "dateFormatted": "20 Jan 2026",
        "timeFormatted": "09:30",
        "officer": "Dr. K. Venkataraman",
        "action": "APPLICATION_INWARD",
        "remark": "Application inward received, processing fees verified, uploaded affidavit registered.",
        "prevHash": "GENESIS_BLOCK_AICTE_REGULATORY_ROOT",
        "hash": "sha256:0a4f89b1c720e3d5"
      },
      {
        "id": "AUDIT-FILE-2026-7644-02",
        "fileId": "FILE-2026-7644",
        "timestamp": "2026-01-28T14:15:00.000Z",
        "dateFormatted": "28 Jan 2026",
        "timeFormatted": "14:15",
        "officer": "Dr. K. Venkataraman",
        "action": "STAGE_ADVANCE",
        "remark": "Docket moved to Document Scrutiny table. Cross-referencing revenue title and Fire NOC.",
        "prevHash": "sha256:0a4f89b1c720e3d5",
        "hash": "sha256:4b91f0c2e819a374"
      }
    ]
  },
  {
    "id": "FILE-2026-7645",
    "fileNumber": "AICTE/SRO/2026-27/1-5020250",
    "instituteName": "Coimbatore Institute of Technology (CIT)",
    "location": "Civil Aerodrome Post, Coimbatore, Tamil Nadu",
    "region": "SRO",
    "intake": 600,
    "complianceScore": 100,
    "currentStageId": 3,
    "daysElapsed": 26,
    "totalSlaDays": 35,
    "status": "DUE_SOON",
    "statusText": "EVC Lab Visit in 2 Days",
    "photoUrl": CAMPUS_PLACEHOLDER_SVG,
    "labPhotoUrl": "https://images.unsplash.com/photo-1517694712202-14dd9538aa97?auto=format&fit=crop&w=1200&q=85",
    "blueprintUrl": BLUEPRINT_PLACEHOLDER_SVG,
    "geoCoords": "11.029° N, 77.027° E",
    "labDetails": "Renewable Energy Systems & Power Electronics Rig",
    "officer": {
      "name": "Shri T. Natarajan",
      "role": "Section Officer",
      "avatar": "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=150&q=80"
    },
    "metrics": {
      "carpetArea": {
        "verified": 7800,
        "required": 5400,
        "unit": "sq.m",
        "ok": true
      },
      "fsr": {
        "actual": "1:13.9",
        "required": "1:15",
        "ok": true
      },
      "fireNoc": {
        "validUntil": "14 Oct 2026",
        "ok": true,
        "label": "TN Fire Service Cleared"
      },
      "landTitle": {
        "registered": true,
        "ok": true,
        "label": "V. Rangasamy Naidu Educational Trust"
      },
      "jointFdr": {
        "amount": "₹1.00 Crore",
        "ok": true,
        "label": "Canara Bank Joint FDR"
      }
    },
    "statusColor": "ochre",
    "stampLabel": "IN SCRUTINY",
    "auditTrail": [
      {
        "id": "AUDIT-FILE-2026-7645-01",
        "fileId": "FILE-2026-7645",
        "timestamp": "2026-01-20T09:30:00.000Z",
        "dateFormatted": "20 Jan 2026",
        "timeFormatted": "09:30",
        "officer": "Shri T. Natarajan",
        "action": "APPLICATION_INWARD",
        "remark": "Application inward received, processing fees verified, uploaded affidavit registered.",
        "prevHash": "GENESIS_BLOCK_AICTE_REGULATORY_ROOT",
        "hash": "sha256:0a4f89b1c720e3d5"
      },
      {
        "id": "AUDIT-FILE-2026-7645-02",
        "fileId": "FILE-2026-7645",
        "timestamp": "2026-01-28T14:15:00.000Z",
        "dateFormatted": "28 Jan 2026",
        "timeFormatted": "14:15",
        "officer": "Shri T. Natarajan",
        "action": "STAGE_ADVANCE",
        "remark": "Docket moved to Document Scrutiny table. Cross-referencing revenue title and Fire NOC.",
        "prevHash": "sha256:0a4f89b1c720e3d5",
        "hash": "sha256:4b91f0c2e819a374"
      }
    ]
  },
  {
    "id": "FILE-2026-7646",
    "fileNumber": "AICTE/SRO/2026-27/1-5020312",
    "instituteName": "Kumaraguru College of Technology (KCT)",
    "location": "Saravanampatti, Coimbatore, Tamil Nadu",
    "region": "SRO",
    "intake": 720,
    "complianceScore": 80,
    "currentStageId": 2,
    "daysElapsed": 11,
    "totalSlaDays": 14,
    "status": "COMPLIANCE_GAP",
    "statusText": "Cadre Proportion Deficit",
    "photoUrl": CAMPUS_PLACEHOLDER_SVG,
    "labPhotoUrl": "https://images.unsplash.com/photo-1581092580497-e0d23cbdf1dc?auto=format&fit=crop&w=1200&q=85",
    "blueprintUrl": BLUEPRINT_PLACEHOLDER_SVG,
    "geoCoords": "11.080° N, 76.989° E",
    "labDetails": "Centre of Excellence in Automotive Engineering & EV Powertrain",
    "officer": {
      "name": "Smt. Meenakshi Sundaram",
      "role": "Doc Auditor",
      "avatar": "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=150&q=80"
    },
    "metrics": {
      "carpetArea": {
        "verified": 9200,
        "required": 6800,
        "unit": "sq.m",
        "ok": true
      },
      "fsr": {
        "actual": "1:16.8",
        "required": "1:15",
        "ok": false
      },
      "fireNoc": {
        "validUntil": "18 Aug 2026",
        "ok": true,
        "label": "Coimbatore Fire Service NOC"
      },
      "landTitle": {
        "registered": true,
        "ok": true,
        "label": "Ramanandha Adigalar Trust Deed"
      },
      "jointFdr": {
        "amount": "₹1.50 Crore",
        "ok": true,
        "label": "Indian Overseas Bank FDR"
      }
    },
    "statusColor": "vermilion",
    "stampLabel": "COMPLIANCE GAP",
    "auditTrail": [
      {
        "id": "AUDIT-FILE-2026-7646-01",
        "fileId": "FILE-2026-7646",
        "timestamp": "2026-01-20T09:30:00.000Z",
        "dateFormatted": "20 Jan 2026",
        "timeFormatted": "09:30",
        "officer": "Smt. Meenakshi Sundaram",
        "action": "APPLICATION_INWARD",
        "remark": "Application inward received, processing fees verified, uploaded affidavit registered.",
        "prevHash": "GENESIS_BLOCK_AICTE_REGULATORY_ROOT",
        "hash": "sha256:0a4f89b1c720e3d5"
      },
      {
        "id": "AUDIT-FILE-2026-7646-02",
        "fileId": "FILE-2026-7646",
        "timestamp": "2026-01-28T14:15:00.000Z",
        "dateFormatted": "28 Jan 2026",
        "timeFormatted": "14:15",
        "officer": "Smt. Meenakshi Sundaram",
        "action": "STAGE_ADVANCE",
        "remark": "Docket moved to Document Scrutiny table. Cross-referencing revenue title and Fire NOC.",
        "prevHash": "sha256:0a4f89b1c720e3d5",
        "hash": "sha256:4b91f0c2e819a374"
      },
      {
        "id": "AUDIT-FILE-2026-7646-03",
        "fileId": "FILE-2026-7646",
        "timestamp": "2026-02-05T11:00:00.000Z",
        "dateFormatted": "05 Feb 2026",
        "timeFormatted": "11:00",
        "officer": "Smt. Meenakshi Sundaram",
        "action": "DEFICIENCY_NOTED",
        "remark": "Statutory deficiency recorded: Cadre Proportion Deficit. Show-cause memo issued.",
        "prevHash": "sha256:4b91f0c2e819a374",
        "hash": "sha256:8f21e09bc471a288"
      }
    ]
  },
  {
    "id": "FILE-2026-7647",
    "fileNumber": "AICTE/SRO/2026-27/1-5020420",
    "instituteName": "Mepco Schlenk Engineering College",
    "location": "Sivakasi, Virudhunagar, Tamil Nadu",
    "region": "SRO",
    "intake": 540,
    "complianceScore": 60,
    "currentStageId": 4,
    "daysElapsed": 42,
    "totalSlaDays": 40,
    "status": "OVERDUE",
    "statusText": "Hearing Adjournment Overdue (+2d)",
    "photoUrl": CAMPUS_PLACEHOLDER_SVG,
    "labPhotoUrl": "https://images.unsplash.com/photo-1532094349884-543bc11b234d?auto=format&fit=crop&w=1200&q=85",
    "blueprintUrl": BLUEPRINT_PLACEHOLDER_SVG,
    "geoCoords": "9.516° N, 77.854° E",
    "labDetails": "Microwave Remote Sensing & Geotechnical Testing Lab",
    "officer": {
      "name": "Dr. K. Venkataraman",
      "role": "Regional Officer",
      "avatar": "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=150&q=80"
    },
    "metrics": {
      "carpetArea": {
        "verified": 6800,
        "required": 4800,
        "unit": "sq.m",
        "ok": true
      },
      "fsr": {
        "actual": "1:17.5",
        "required": "1:15",
        "ok": false
      },
      "fireNoc": {
        "validUntil": "10 Feb 2026",
        "ok": false,
        "label": "Expired 2 Weeks Ago"
      },
      "landTitle": {
        "registered": true,
        "ok": true,
        "label": "Mepco Trust Freehold (100 Acres)"
      },
      "jointFdr": {
        "amount": "₹1.00 Crore",
        "ok": true,
        "label": "Tamilnad Mercantile Bank FDR"
      }
    },
    "statusColor": "vermilion",
    "stampLabel": "URGENT OVERDUE",
    "auditTrail": [
      {
        "id": "AUDIT-FILE-2026-7647-01",
        "fileId": "FILE-2026-7647",
        "timestamp": "2026-01-20T09:30:00.000Z",
        "dateFormatted": "20 Jan 2026",
        "timeFormatted": "09:30",
        "officer": "Dr. K. Venkataraman",
        "action": "APPLICATION_INWARD",
        "remark": "Application inward received, processing fees verified, uploaded affidavit registered.",
        "prevHash": "GENESIS_BLOCK_AICTE_REGULATORY_ROOT",
        "hash": "sha256:0a4f89b1c720e3d5"
      },
      {
        "id": "AUDIT-FILE-2026-7647-02",
        "fileId": "FILE-2026-7647",
        "timestamp": "2026-01-28T14:15:00.000Z",
        "dateFormatted": "28 Jan 2026",
        "timeFormatted": "14:15",
        "officer": "Dr. K. Venkataraman",
        "action": "STAGE_ADVANCE",
        "remark": "Docket moved to Document Scrutiny table. Cross-referencing revenue title and Fire NOC.",
        "prevHash": "sha256:0a4f89b1c720e3d5",
        "hash": "sha256:4b91f0c2e819a374"
      }
    ]
  },
  {
    "id": "FILE-2026-7648",
    "fileNumber": "AICTE/SRO/2026-27/1-5020519",
    "instituteName": "Government College of Technology (GCT)",
    "location": "Thadagam Road, Coimbatore, Tamil Nadu",
    "region": "SRO",
    "intake": 480,
    "complianceScore": 100,
    "currentStageId": 1,
    "daysElapsed": 2,
    "totalSlaDays": 7,
    "status": "ON_TRACK",
    "statusText": "Fee Reconciled via Treasury",
    "photoUrl": CAMPUS_PLACEHOLDER_SVG,
    "labPhotoUrl": "https://images.unsplash.com/photo-1581092795360-fd1ca04f0952?auto=format&fit=crop&w=1200&q=85",
    "blueprintUrl": BLUEPRINT_PLACEHOLDER_SVG,
    "geoCoords": "11.018° N, 76.937° E",
    "labDetails": "Structural Concrete Mechanics & Water Treatment Facility",
    "officer": {
      "name": "Shri T. Natarajan",
      "role": "Section Officer",
      "avatar": "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=150&q=80"
    },
    "metrics": {
      "carpetArea": {
        "verified": 7200,
        "required": 4800,
        "unit": "sq.m",
        "ok": true
      },
      "fsr": {
        "actual": "1:13.6",
        "required": "1:15",
        "ok": true
      },
      "fireNoc": {
        "validUntil": "25 Nov 2026",
        "ok": true,
        "label": "TN Fire Service Cleared"
      },
      "landTitle": {
        "registered": true,
        "ok": true,
        "label": "Government of Tamil Nadu Campus"
      },
      "jointFdr": {
        "amount": "₹1.00 Crore",
        "ok": true,
        "label": "State Bank of India FDR"
      }
    },
    "statusColor": "pine",
    "stampLabel": "IN SCRUTINY",
    "auditTrail": [
      {
        "id": "AUDIT-FILE-2026-7648-01",
        "fileId": "FILE-2026-7648",
        "timestamp": "2026-01-20T09:30:00.000Z",
        "dateFormatted": "20 Jan 2026",
        "timeFormatted": "09:30",
        "officer": "Shri T. Natarajan",
        "action": "APPLICATION_INWARD",
        "remark": "Application inward received, processing fees verified, uploaded affidavit registered.",
        "prevHash": "GENESIS_BLOCK_AICTE_REGULATORY_ROOT",
        "hash": "sha256:0a4f89b1c720e3d5"
      }
    ]
  },
  {
    "id": "FILE-2026-7649",
    "fileNumber": "AICTE/SRO/2026-27/1-5020625",
    "instituteName": "Bannari Amman Institute of Technology (BIT)",
    "location": "Sathyamangalam, Erode, Tamil Nadu",
    "region": "SRO",
    "intake": 660,
    "complianceScore": 100,
    "currentStageId": 3,
    "daysElapsed": 24,
    "totalSlaDays": 35,
    "status": "ON_TRACK",
    "statusText": "Physical Audit Cleared",
    "photoUrl": CAMPUS_PLACEHOLDER_SVG,
    "labPhotoUrl": "https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?auto=format&fit=crop&w=1200&q=85",
    "blueprintUrl": BLUEPRINT_PLACEHOLDER_SVG,
    "geoCoords": "11.503° N, 77.276° E",
    "labDetails": "Agri-Tech Robotics & Precision Bio-Engineering Center",
    "officer": {
      "name": "Shri T. Natarajan",
      "role": "Section Officer",
      "avatar": "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=150&q=80"
    },
    "metrics": {
      "carpetArea": {
        "verified": 9800,
        "required": 6400,
        "unit": "sq.m",
        "ok": true
      },
      "fsr": {
        "actual": "1:13.2",
        "required": "1:15",
        "ok": true
      },
      "fireNoc": {
        "validUntil": "19 Sep 2027",
        "ok": true,
        "label": "Erode Fire Service NOC"
      },
      "landTitle": {
        "registered": true,
        "ok": true,
        "label": "Bannari Amman Trust (180 Acres)"
      },
      "jointFdr": {
        "amount": "₹1.50 Crore",
        "ok": true,
        "label": "Indian Bank Joint FDR"
      }
    },
    "statusColor": "pine",
    "stampLabel": "IN SCRUTINY",
    "auditTrail": [
      {
        "id": "AUDIT-FILE-2026-7649-01",
        "fileId": "FILE-2026-7649",
        "timestamp": "2026-01-20T09:30:00.000Z",
        "dateFormatted": "20 Jan 2026",
        "timeFormatted": "09:30",
        "officer": "Shri T. Natarajan",
        "action": "APPLICATION_INWARD",
        "remark": "Application inward received, processing fees verified, uploaded affidavit registered.",
        "prevHash": "GENESIS_BLOCK_AICTE_REGULATORY_ROOT",
        "hash": "sha256:0a4f89b1c720e3d5"
      },
      {
        "id": "AUDIT-FILE-2026-7649-02",
        "fileId": "FILE-2026-7649",
        "timestamp": "2026-01-28T14:15:00.000Z",
        "dateFormatted": "28 Jan 2026",
        "timeFormatted": "14:15",
        "officer": "Shri T. Natarajan",
        "action": "STAGE_ADVANCE",
        "remark": "Docket moved to Document Scrutiny table. Cross-referencing revenue title and Fire NOC.",
        "prevHash": "sha256:0a4f89b1c720e3d5",
        "hash": "sha256:4b91f0c2e819a374"
      }
    ]
  },
  {
    "id": "FILE-2026-7650",
    "fileNumber": "AICTE/SRO/2026-27/1-5020733",
    "instituteName": "Sri Krishna College of Engg & Tech (SKCET)",
    "location": "Kuniamuthur, Coimbatore, Tamil Nadu",
    "region": "SRO",
    "intake": 600,
    "complianceScore": 100,
    "currentStageId": 2,
    "daysElapsed": 10,
    "totalSlaDays": 14,
    "status": "DUE_SOON",
    "statusText": "Scrutiny Closes in 3 Days",
    "photoUrl": CAMPUS_PLACEHOLDER_SVG,
    "labPhotoUrl": "https://images.unsplash.com/photo-1558494949-ef010cbdcc31?auto=format&fit=crop&w=1200&q=85",
    "blueprintUrl": BLUEPRINT_PLACEHOLDER_SVG,
    "geoCoords": "10.938° N, 76.955° E",
    "labDetails": "Cloud Virtualization & Cybersecurity Testing Lab",
    "officer": {
      "name": "Smt. Meenakshi Sundaram",
      "role": "Doc Auditor",
      "avatar": "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=150&q=80"
    },
    "metrics": {
      "carpetArea": {
        "verified": 8100,
        "required": 5400,
        "unit": "sq.m",
        "ok": true
      },
      "fsr": {
        "actual": "1:14.3",
        "required": "1:15",
        "ok": true
      },
      "fireNoc": {
        "validUntil": "30 Oct 2026",
        "ok": true,
        "label": "TN Fire Safety Valid"
      },
      "landTitle": {
        "registered": true,
        "ok": true,
        "label": "VLB Trust Registered Freehold"
      },
      "jointFdr": {
        "amount": "₹1.00 Crore",
        "ok": true,
        "label": "Axis Bank Joint FDR"
      }
    },
    "statusColor": "ochre",
    "stampLabel": "IN SCRUTINY",
    "auditTrail": [
      {
        "id": "AUDIT-FILE-2026-7650-01",
        "fileId": "FILE-2026-7650",
        "timestamp": "2026-01-20T09:30:00.000Z",
        "dateFormatted": "20 Jan 2026",
        "timeFormatted": "09:30",
        "officer": "Smt. Meenakshi Sundaram",
        "action": "APPLICATION_INWARD",
        "remark": "Application inward received, processing fees verified, uploaded affidavit registered.",
        "prevHash": "GENESIS_BLOCK_AICTE_REGULATORY_ROOT",
        "hash": "sha256:0a4f89b1c720e3d5"
      },
      {
        "id": "AUDIT-FILE-2026-7650-02",
        "fileId": "FILE-2026-7650",
        "timestamp": "2026-01-28T14:15:00.000Z",
        "dateFormatted": "28 Jan 2026",
        "timeFormatted": "14:15",
        "officer": "Smt. Meenakshi Sundaram",
        "action": "STAGE_ADVANCE",
        "remark": "Docket moved to Document Scrutiny table. Cross-referencing revenue title and Fire NOC.",
        "prevHash": "sha256:0a4f89b1c720e3d5",
        "hash": "sha256:4b91f0c2e819a374"
      }
    ]
  },
  {
    "id": "FILE-2026-7651",
    "fileNumber": "AICTE/SRO/2026-27/1-5020845",
    "instituteName": "National Engineering College (NEC)",
    "location": "K.R. Nagar, Kovilpatti, Tamil Nadu",
    "region": "SRO",
    "intake": 420,
    "complianceScore": 100,
    "currentStageId": 1,
    "daysElapsed": 5,
    "totalSlaDays": 7,
    "status": "DUE_SOON",
    "statusText": "Processing Fee Recheck",
    "photoUrl": CAMPUS_PLACEHOLDER_SVG,
    "labPhotoUrl": "https://images.unsplash.com/photo-1581092162384-8987c1d64718?auto=format&fit=crop&w=1200&q=85",
    "blueprintUrl": BLUEPRINT_PLACEHOLDER_SVG,
    "geoCoords": "9.175° N, 77.871° E",
    "labDetails": "Smart Grid & Solar Thermal Energy Testbed",
    "officer": {
      "name": "Shri T. Natarajan",
      "role": "Section Officer",
      "avatar": "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=150&q=80"
    },
    "metrics": {
      "carpetArea": {
        "verified": 5900,
        "required": 4200,
        "unit": "sq.m",
        "ok": true
      },
      "fsr": {
        "actual": "1:14.7",
        "required": "1:15",
        "ok": true
      },
      "fireNoc": {
        "validUntil": "15 Jul 2026",
        "ok": true,
        "label": "Kovilpatti Fire Station NOC"
      },
      "landTitle": {
        "registered": true,
        "ok": true,
        "label": "K.R. Trust Registered Property"
      },
      "jointFdr": {
        "amount": "₹1.00 Crore",
        "ok": true,
        "label": "Canara Bank FDR"
      }
    },
    "statusColor": "ochre",
    "stampLabel": "IN SCRUTINY",
    "auditTrail": [
      {
        "id": "AUDIT-FILE-2026-7651-01",
        "fileId": "FILE-2026-7651",
        "timestamp": "2026-01-20T09:30:00.000Z",
        "dateFormatted": "20 Jan 2026",
        "timeFormatted": "09:30",
        "officer": "Shri T. Natarajan",
        "action": "APPLICATION_INWARD",
        "remark": "Application inward received, processing fees verified, uploaded affidavit registered.",
        "prevHash": "GENESIS_BLOCK_AICTE_REGULATORY_ROOT",
        "hash": "sha256:0a4f89b1c720e3d5"
      }
    ]
  },
  {
    "id": "FILE-2026-6519",
    "fileNumber": "AICTE/NWRO/2026-27/1-2918801",
    "instituteName": "Maharaja Agrasen Institute of Technology",
    "location": "Rohini, New Delhi",
    "region": "NWRO",
    "intake": 300,
    "complianceScore": 60,
    "currentStageId": 4,
    "daysElapsed": 44,
    "totalSlaDays": 40,
    "status": "OVERDUE",
    "statusText": "SLA Overdue (+4 Days)",
    "photoUrl": CAMPUS_PLACEHOLDER_SVG,
    "labPhotoUrl": "https://images.unsplash.com/photo-1517048676732-d65bc937f952?auto=format&fit=crop&w=1200&q=85",
    "blueprintUrl": BLUEPRINT_PLACEHOLDER_SVG,
    "geoCoords": "28.718° N, 77.067° E",
    "labDetails": "Software Systems & Cloud Engineering Laboratory",
    "officer": {
      "name": "Shri Rajiv Bajaj",
      "role": "Regional Officer",
      "avatar": "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&w=150&q=80"
    },
    "metrics": {
      "carpetArea": {
        "verified": 4100,
        "required": 4200,
        "unit": "sq.m",
        "ok": false
      },
      "fsr": {
        "actual": "1:18.4",
        "required": "1:15",
        "ok": false
      },
      "fireNoc": {
        "validUntil": "20 May 2026",
        "ok": true,
        "label": "Delhi Fire Service"
      },
      "landTitle": {
        "registered": true,
        "ok": true,
        "label": "Verified Society Deed"
      },
      "jointFdr": {
        "amount": "₹1.00 Crore",
        "ok": true,
        "label": "Canara Bank Joint FDR"
      }
    },
    "statusColor": "vermilion",
    "stampLabel": "URGENT OVERDUE",
    "auditTrail": [
      {
        "id": "AUDIT-FILE-2026-6519-01",
        "fileId": "FILE-2026-6519",
        "timestamp": "2026-01-20T09:30:00.000Z",
        "dateFormatted": "20 Jan 2026",
        "timeFormatted": "09:30",
        "officer": "Shri Rajiv Bajaj",
        "action": "APPLICATION_INWARD",
        "remark": "Application inward received, processing fees verified, uploaded affidavit registered.",
        "prevHash": "GENESIS_BLOCK_AICTE_REGULATORY_ROOT",
        "hash": "sha256:0a4f89b1c720e3d5"
      },
      {
        "id": "AUDIT-FILE-2026-6519-02",
        "fileId": "FILE-2026-6519",
        "timestamp": "2026-01-28T14:15:00.000Z",
        "dateFormatted": "28 Jan 2026",
        "timeFormatted": "14:15",
        "officer": "Shri Rajiv Bajaj",
        "action": "STAGE_ADVANCE",
        "remark": "Docket moved to Document Scrutiny table. Cross-referencing revenue title and Fire NOC.",
        "prevHash": "sha256:0a4f89b1c720e3d5",
        "hash": "sha256:4b91f0c2e819a374"
      }
    ]
  },
  {
    "id": "FILE-2026-6520",
    "fileNumber": "AICTE/NWRO/2026-27/1-2918845",
    "instituteName": "Thapar Institute of Engineering & Technology",
    "location": "Patiala, Punjab",
    "region": "NWRO",
    "intake": 660,
    "complianceScore": 100,
    "currentStageId": 3,
    "daysElapsed": 26,
    "totalSlaDays": 35,
    "status": "ON_TRACK",
    "statusText": "EVC Committee On-Site",
    "photoUrl": CAMPUS_PLACEHOLDER_SVG,
    "labPhotoUrl": "https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?auto=format&fit=crop&w=1200&q=85",
    "blueprintUrl": BLUEPRINT_PLACEHOLDER_SVG,
    "geoCoords": "30.356° N, 76.364° E",
    "labDetails": "Cyber-Physical Systems & Automation Testbed",
    "officer": {
      "name": "Prof. Harpreet Singh",
      "role": "EVC Team Lead",
      "avatar": "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=150&q=80"
    },
    "metrics": {
      "carpetArea": {
        "verified": 8900,
        "required": 6400,
        "unit": "sq.m",
        "ok": true
      },
      "fsr": {
        "actual": "1:13.4",
        "required": "1:15",
        "ok": true
      },
      "fireNoc": {
        "validUntil": "15 Sep 2027",
        "ok": true,
        "label": "Punjab Fire Service NOC"
      },
      "landTitle": {
        "registered": true,
        "ok": true,
        "label": "250-Acre Campus Registered"
      },
      "jointFdr": {
        "amount": "₹1.50 Crore",
        "ok": true,
        "label": "State Bank of India FDR"
      }
    },
    "statusColor": "pine",
    "stampLabel": "IN SCRUTINY",
    "auditTrail": [
      {
        "id": "AUDIT-FILE-2026-6520-01",
        "fileId": "FILE-2026-6520",
        "timestamp": "2026-01-20T09:30:00.000Z",
        "dateFormatted": "20 Jan 2026",
        "timeFormatted": "09:30",
        "officer": "Prof. Harpreet Singh",
        "action": "APPLICATION_INWARD",
        "remark": "Application inward received, processing fees verified, uploaded affidavit registered.",
        "prevHash": "GENESIS_BLOCK_AICTE_REGULATORY_ROOT",
        "hash": "sha256:0a4f89b1c720e3d5"
      },
      {
        "id": "AUDIT-FILE-2026-6520-02",
        "fileId": "FILE-2026-6520",
        "timestamp": "2026-01-28T14:15:00.000Z",
        "dateFormatted": "28 Jan 2026",
        "timeFormatted": "14:15",
        "officer": "Prof. Harpreet Singh",
        "action": "STAGE_ADVANCE",
        "remark": "Docket moved to Document Scrutiny table. Cross-referencing revenue title and Fire NOC.",
        "prevHash": "sha256:0a4f89b1c720e3d5",
        "hash": "sha256:4b91f0c2e819a374"
      }
    ]
  },
  {
    "id": "FILE-2026-6521",
    "fileNumber": "AICTE/NWRO/2026-27/1-2918910",
    "instituteName": "Guru Nanak Dev Engineering College",
    "location": "Gill Park, Ludhiana, Punjab",
    "region": "NWRO",
    "intake": 420,
    "complianceScore": 100,
    "currentStageId": 2,
    "daysElapsed": 13,
    "totalSlaDays": 14,
    "status": "DUE_SOON",
    "statusText": "Doc Audit Closes Tomorrow",
    "photoUrl": CAMPUS_PLACEHOLDER_SVG,
    "labPhotoUrl": "https://images.unsplash.com/photo-1581092795360-fd1ca04f0952?auto=format&fit=crop&w=1200&q=85",
    "blueprintUrl": BLUEPRINT_PLACEHOLDER_SVG,
    "geoCoords": "30.860° N, 75.859° E",
    "labDetails": "Heavy Power Machinery & Fluid Dynamics Lab",
    "officer": {
      "name": "Shri Jaswinder Sandhu",
      "role": "Scrutiny Member",
      "avatar": "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=150&q=80"
    },
    "metrics": {
      "carpetArea": {
        "verified": 5400,
        "required": 4200,
        "unit": "sq.m",
        "ok": true
      },
      "fsr": {
        "actual": "1:14.8",
        "required": "1:15",
        "ok": true
      },
      "fireNoc": {
        "validUntil": "10 Jul 2026",
        "ok": true,
        "label": "Ludhiana Municipal Fire NOC"
      },
      "landTitle": {
        "registered": true,
        "ok": true,
        "label": "Trust Property Deed"
      },
      "jointFdr": {
        "amount": "₹1.00 Crore",
        "ok": true,
        "label": "Punjab & Sind Bank FDR"
      }
    },
    "statusColor": "ochre",
    "stampLabel": "IN SCRUTINY",
    "auditTrail": [
      {
        "id": "AUDIT-FILE-2026-6521-01",
        "fileId": "FILE-2026-6521",
        "timestamp": "2026-01-20T09:30:00.000Z",
        "dateFormatted": "20 Jan 2026",
        "timeFormatted": "09:30",
        "officer": "Shri Jaswinder Sandhu",
        "action": "APPLICATION_INWARD",
        "remark": "Application inward received, processing fees verified, uploaded affidavit registered.",
        "prevHash": "GENESIS_BLOCK_AICTE_REGULATORY_ROOT",
        "hash": "sha256:0a4f89b1c720e3d5"
      },
      {
        "id": "AUDIT-FILE-2026-6521-02",
        "fileId": "FILE-2026-6521",
        "timestamp": "2026-01-28T14:15:00.000Z",
        "dateFormatted": "28 Jan 2026",
        "timeFormatted": "14:15",
        "officer": "Shri Jaswinder Sandhu",
        "action": "STAGE_ADVANCE",
        "remark": "Docket moved to Document Scrutiny table. Cross-referencing revenue title and Fire NOC.",
        "prevHash": "sha256:0a4f89b1c720e3d5",
        "hash": "sha256:4b91f0c2e819a374"
      }
    ]
  },
  {
    "id": "FILE-2026-5201",
    "fileNumber": "AICTE/SCRO/2026-27/1-4190823",
    "instituteName": "Chaitanya Bharathi Institute of Tech (CBIT)",
    "location": "Gandipet, Hyderabad, Telangana",
    "region": "SCRO",
    "intake": 600,
    "complianceScore": 100,
    "currentStageId": 5,
    "daysElapsed": 42,
    "totalSlaDays": 45,
    "status": "ON_TRACK",
    "statusText": "Ready for LoA Issuance",
    "photoUrl": CAMPUS_PLACEHOLDER_SVG,
    "labPhotoUrl": "https://images.unsplash.com/photo-1517694712202-14dd9538aa97?auto=format&fit=crop&w=1200&q=85",
    "blueprintUrl": BLUEPRINT_PLACEHOLDER_SVG,
    "geoCoords": "17.391° N, 78.319° E",
    "labDetails": "Centre for Innovation & AI Incubation Hub",
    "officer": {
      "name": "Dr. B. K. Murthy",
      "role": "Member Secretary",
      "avatar": "https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?auto=format&fit=crop&w=150&q=80"
    },
    "metrics": {
      "carpetArea": {
        "verified": 7800,
        "required": 5400,
        "unit": "sq.m",
        "ok": true
      },
      "fsr": {
        "actual": "1:12.5",
        "required": "1:15",
        "ok": true
      },
      "fireNoc": {
        "validUntil": "15 Nov 2027",
        "ok": true,
        "label": "Telangana Disaster NOC"
      },
      "landTitle": {
        "registered": true,
        "ok": true,
        "label": "50.8 Acres Campus Freehold"
      },
      "jointFdr": {
        "amount": "₹1.00 Crore",
        "ok": true,
        "label": "SBI Joint FDR Active"
      }
    },
    "statusColor": "pine",
    "stampLabel": "COUNCIL ORDER",
    "auditTrail": [
      {
        "id": "AUDIT-FILE-2026-5201-01",
        "fileId": "FILE-2026-5201",
        "timestamp": "2026-01-20T09:30:00.000Z",
        "dateFormatted": "20 Jan 2026",
        "timeFormatted": "09:30",
        "officer": "Dr. B. K. Murthy",
        "action": "APPLICATION_INWARD",
        "remark": "Application inward received, processing fees verified, uploaded affidavit registered.",
        "prevHash": "GENESIS_BLOCK_AICTE_REGULATORY_ROOT",
        "hash": "sha256:0a4f89b1c720e3d5"
      },
      {
        "id": "AUDIT-FILE-2026-5201-02",
        "fileId": "FILE-2026-5201",
        "timestamp": "2026-01-28T14:15:00.000Z",
        "dateFormatted": "28 Jan 2026",
        "timeFormatted": "14:15",
        "officer": "Dr. B. K. Murthy",
        "action": "STAGE_ADVANCE",
        "remark": "Docket moved to Document Scrutiny table. Cross-referencing revenue title and Fire NOC.",
        "prevHash": "sha256:0a4f89b1c720e3d5",
        "hash": "sha256:4b91f0c2e819a374"
      }
    ]
  },
  {
    "id": "FILE-2026-5202",
    "fileNumber": "AICTE/SCRO/2026-27/1-4190888",
    "instituteName": "Gayatri Vidya Parishad College of Engg",
    "location": "Madhurawada, Visakhapatnam, Andhra Pradesh",
    "region": "SCRO",
    "intake": 540,
    "complianceScore": 80,
    "currentStageId": 2,
    "daysElapsed": 11,
    "totalSlaDays": 14,
    "status": "COMPLIANCE_GAP",
    "statusText": "Cadre Ratio Discrepancy",
    "photoUrl": CAMPUS_PLACEHOLDER_SVG,
    "labPhotoUrl": "https://images.unsplash.com/photo-1581092160607-ee22621dd758?auto=format&fit=crop&w=1200&q=85",
    "blueprintUrl": BLUEPRINT_PLACEHOLDER_SVG,
    "geoCoords": "17.820° N, 83.342° E",
    "labDetails": "Renewable Wind & Solar Microgrid Lab",
    "officer": {
      "name": "Shri P. Satyanarayana",
      "role": "Academic Scrutinizer",
      "avatar": "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&w=150&q=80"
    },
    "metrics": {
      "carpetArea": {
        "verified": 5900,
        "required": 4800,
        "unit": "sq.m",
        "ok": true
      },
      "fsr": {
        "actual": "1:17.0",
        "required": "1:15",
        "ok": false
      },
      "fireNoc": {
        "validUntil": "24 Dec 2026",
        "ok": true,
        "label": "AP State Disaster NOC"
      },
      "landTitle": {
        "registered": true,
        "ok": true,
        "label": "Society Leasehold (20 Acres)"
      },
      "jointFdr": {
        "amount": "₹1.00 Crore",
        "ok": true,
        "label": "Andhra Bank FDR"
      }
    },
    "statusColor": "vermilion",
    "stampLabel": "COMPLIANCE GAP",
    "auditTrail": [
      {
        "id": "AUDIT-FILE-2026-5202-01",
        "fileId": "FILE-2026-5202",
        "timestamp": "2026-01-20T09:30:00.000Z",
        "dateFormatted": "20 Jan 2026",
        "timeFormatted": "09:30",
        "officer": "Shri P. Satyanarayana",
        "action": "APPLICATION_INWARD",
        "remark": "Application inward received, processing fees verified, uploaded affidavit registered.",
        "prevHash": "GENESIS_BLOCK_AICTE_REGULATORY_ROOT",
        "hash": "sha256:0a4f89b1c720e3d5"
      },
      {
        "id": "AUDIT-FILE-2026-5202-02",
        "fileId": "FILE-2026-5202",
        "timestamp": "2026-01-28T14:15:00.000Z",
        "dateFormatted": "28 Jan 2026",
        "timeFormatted": "14:15",
        "officer": "Shri P. Satyanarayana",
        "action": "STAGE_ADVANCE",
        "remark": "Docket moved to Document Scrutiny table. Cross-referencing revenue title and Fire NOC.",
        "prevHash": "sha256:0a4f89b1c720e3d5",
        "hash": "sha256:4b91f0c2e819a374"
      },
      {
        "id": "AUDIT-FILE-2026-5202-03",
        "fileId": "FILE-2026-5202",
        "timestamp": "2026-02-05T11:00:00.000Z",
        "dateFormatted": "05 Feb 2026",
        "timeFormatted": "11:00",
        "officer": "Shri P. Satyanarayana",
        "action": "DEFICIENCY_NOTED",
        "remark": "Statutory deficiency recorded: Cadre Ratio Discrepancy. Show-cause memo issued.",
        "prevHash": "sha256:4b91f0c2e819a374",
        "hash": "sha256:8f21e09bc471a288"
      }
    ]
  },
  {
    "id": "FILE-2026-5203",
    "fileNumber": "AICTE/SCRO/2026-27/1-4190950",
    "instituteName": "Vasavi College of Engineering",
    "location": "Ibrahimbagh, Hyderabad, Telangana",
    "region": "SCRO",
    "intake": 480,
    "complianceScore": 100,
    "currentStageId": 3,
    "daysElapsed": 25,
    "totalSlaDays": 35,
    "status": "ON_TRACK",
    "statusText": "Physical Lab Passed",
    "photoUrl": CAMPUS_PLACEHOLDER_SVG,
    "labPhotoUrl": "https://images.unsplash.com/photo-1581092162384-8987c1d64718?auto=format&fit=crop&w=1200&q=85",
    "blueprintUrl": BLUEPRINT_PLACEHOLDER_SVG,
    "geoCoords": "17.380° N, 78.382° E",
    "labDetails": "Advanced Microwave & Antenna Design Testing Facility",
    "officer": {
      "name": "Smt. V. Anuradha",
      "role": "Inspection Secretary",
      "avatar": "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=150&q=80"
    },
    "metrics": {
      "carpetArea": {
        "verified": 6700,
        "required": 4800,
        "unit": "sq.m",
        "ok": true
      },
      "fsr": {
        "actual": "1:13.9",
        "required": "1:15",
        "ok": true
      },
      "fireNoc": {
        "validUntil": "19 Nov 2026",
        "ok": true,
        "label": "Telangana Fire Dept NOC"
      },
      "landTitle": {
        "registered": true,
        "ok": true,
        "label": "Freehold Registered Document"
      },
      "jointFdr": {
        "amount": "₹1.00 Crore",
        "ok": true,
        "label": "Canara Bank Joint FDR"
      }
    },
    "statusColor": "pine",
    "stampLabel": "IN SCRUTINY",
    "auditTrail": [
      {
        "id": "AUDIT-FILE-2026-5203-01",
        "fileId": "FILE-2026-5203",
        "timestamp": "2026-01-20T09:30:00.000Z",
        "dateFormatted": "20 Jan 2026",
        "timeFormatted": "09:30",
        "officer": "Smt. V. Anuradha",
        "action": "APPLICATION_INWARD",
        "remark": "Application inward received, processing fees verified, uploaded affidavit registered.",
        "prevHash": "GENESIS_BLOCK_AICTE_REGULATORY_ROOT",
        "hash": "sha256:0a4f89b1c720e3d5"
      },
      {
        "id": "AUDIT-FILE-2026-5203-02",
        "fileId": "FILE-2026-5203",
        "timestamp": "2026-01-28T14:15:00.000Z",
        "dateFormatted": "28 Jan 2026",
        "timeFormatted": "14:15",
        "officer": "Smt. V. Anuradha",
        "action": "STAGE_ADVANCE",
        "remark": "Docket moved to Document Scrutiny table. Cross-referencing revenue title and Fire NOC.",
        "prevHash": "sha256:0a4f89b1c720e3d5",
        "hash": "sha256:4b91f0c2e819a374"
      }
    ]
  },
  {
    "id": "FILE-2026-4101",
    "fileNumber": "AICTE/ERO/2026-27/1-6019234",
    "instituteName": "Heritage Institute of Technology",
    "location": "Anandapur, Kolkata, West Bengal",
    "region": "ERO",
    "intake": 540,
    "complianceScore": 100,
    "currentStageId": 3,
    "daysElapsed": 29,
    "totalSlaDays": 35,
    "status": "DUE_SOON",
    "statusText": "Lab Verification in 3 Days",
    "photoUrl": CAMPUS_PLACEHOLDER_SVG,
    "labPhotoUrl": "https://images.unsplash.com/photo-1558494949-ef010cbdcc31?auto=format&fit=crop&w=1200&q=85",
    "blueprintUrl": BLUEPRINT_PLACEHOLDER_SVG,
    "geoCoords": "22.518° N, 88.418° E",
    "labDetails": "Centre for Data Science & Cybersecurity Cluster",
    "officer": {
      "name": "Dr. Subir Banerjee",
      "role": "EVC Convener",
      "avatar": "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=150&q=80"
    },
    "metrics": {
      "carpetArea": {
        "verified": 6900,
        "required": 4800,
        "unit": "sq.m",
        "ok": true
      },
      "fsr": {
        "actual": "1:14.2",
        "required": "1:15",
        "ok": true
      },
      "fireNoc": {
        "validUntil": "08 Oct 2026",
        "ok": true,
        "label": "WB Fire Services Cleared"
      },
      "landTitle": {
        "registered": true,
        "ok": true,
        "label": "Clear Deed (10 Acres)"
      },
      "jointFdr": {
        "amount": "₹1.00 Crore",
        "ok": true,
        "label": "Axis Bank Joint FDR"
      }
    },
    "statusColor": "ochre",
    "stampLabel": "IN SCRUTINY",
    "auditTrail": [
      {
        "id": "AUDIT-FILE-2026-4101-01",
        "fileId": "FILE-2026-4101",
        "timestamp": "2026-01-20T09:30:00.000Z",
        "dateFormatted": "20 Jan 2026",
        "timeFormatted": "09:30",
        "officer": "Dr. Subir Banerjee",
        "action": "APPLICATION_INWARD",
        "remark": "Application inward received, processing fees verified, uploaded affidavit registered.",
        "prevHash": "GENESIS_BLOCK_AICTE_REGULATORY_ROOT",
        "hash": "sha256:0a4f89b1c720e3d5"
      },
      {
        "id": "AUDIT-FILE-2026-4101-02",
        "fileId": "FILE-2026-4101",
        "timestamp": "2026-01-28T14:15:00.000Z",
        "dateFormatted": "28 Jan 2026",
        "timeFormatted": "14:15",
        "officer": "Dr. Subir Banerjee",
        "action": "STAGE_ADVANCE",
        "remark": "Docket moved to Document Scrutiny table. Cross-referencing revenue title and Fire NOC.",
        "prevHash": "sha256:0a4f89b1c720e3d5",
        "hash": "sha256:4b91f0c2e819a374"
      }
    ]
  },
  {
    "id": "FILE-2026-4102",
    "fileNumber": "AICTE/ERO/2026-27/1-6019312",
    "instituteName": "National Institute of Science & Technology",
    "location": "Palur Hills, Berhampur, Odisha",
    "region": "ERO",
    "intake": 420,
    "complianceScore": 80,
    "currentStageId": 2,
    "daysElapsed": 12,
    "totalSlaDays": 14,
    "status": "COMPLIANCE_GAP",
    "statusText": "Library Title Deficit",
    "photoUrl": CAMPUS_PLACEHOLDER_SVG,
    "labPhotoUrl": "https://images.unsplash.com/photo-1507668077129-56e32842fceb?auto=format&fit=crop&w=1200&q=85",
    "blueprintUrl": BLUEPRINT_PLACEHOLDER_SVG,
    "geoCoords": "19.168° N, 84.887° E",
    "labDetails": "Renewable Energy & Applied Optics Testing Park",
    "officer": {
      "name": "Smt. Tanushree Mohapatra",
      "role": "Verification Officer",
      "avatar": "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=150&q=80"
    },
    "metrics": {
      "carpetArea": {
        "verified": 4950,
        "required": 4200,
        "unit": "sq.m",
        "ok": true
      },
      "fsr": {
        "actual": "1:15.5",
        "required": "1:15",
        "ok": false
      },
      "fireNoc": {
        "validUntil": "14 Jul 2026",
        "ok": true,
        "label": "Odisha Fire Safety Certificate"
      },
      "landTitle": {
        "registered": true,
        "ok": true,
        "label": "Autonomous Campus (30 Acres)"
      },
      "jointFdr": {
        "amount": "₹1.00 Crore",
        "ok": true,
        "label": "UCO Bank FDR Active"
      }
    },
    "statusColor": "vermilion",
    "stampLabel": "COMPLIANCE GAP",
    "auditTrail": [
      {
        "id": "AUDIT-FILE-2026-4102-01",
        "fileId": "FILE-2026-4102",
        "timestamp": "2026-01-20T09:30:00.000Z",
        "dateFormatted": "20 Jan 2026",
        "timeFormatted": "09:30",
        "officer": "Smt. Tanushree Mohapatra",
        "action": "APPLICATION_INWARD",
        "remark": "Application inward received, processing fees verified, uploaded affidavit registered.",
        "prevHash": "GENESIS_BLOCK_AICTE_REGULATORY_ROOT",
        "hash": "sha256:0a4f89b1c720e3d5"
      },
      {
        "id": "AUDIT-FILE-2026-4102-02",
        "fileId": "FILE-2026-4102",
        "timestamp": "2026-01-28T14:15:00.000Z",
        "dateFormatted": "28 Jan 2026",
        "timeFormatted": "14:15",
        "officer": "Smt. Tanushree Mohapatra",
        "action": "STAGE_ADVANCE",
        "remark": "Docket moved to Document Scrutiny table. Cross-referencing revenue title and Fire NOC.",
        "prevHash": "sha256:0a4f89b1c720e3d5",
        "hash": "sha256:4b91f0c2e819a374"
      },
      {
        "id": "AUDIT-FILE-2026-4102-03",
        "fileId": "FILE-2026-4102",
        "timestamp": "2026-02-05T11:00:00.000Z",
        "dateFormatted": "05 Feb 2026",
        "timeFormatted": "11:00",
        "officer": "Smt. Tanushree Mohapatra",
        "action": "DEFICIENCY_NOTED",
        "remark": "Statutory deficiency recorded: Library Title Deficit. Show-cause memo issued.",
        "prevHash": "sha256:4b91f0c2e819a374",
        "hash": "sha256:8f21e09bc471a288"
      }
    ]
  },
  {
    "id": "FILE-2026-4103",
    "fileNumber": "AICTE/ERO/2026-27/1-6019488",
    "instituteName": "Muzaffarpur Institute of Technology",
    "location": "Muzaffarpur, Bihar",
    "region": "ERO",
    "intake": 360,
    "complianceScore": 40,
    "currentStageId": 4,
    "daysElapsed": 43,
    "totalSlaDays": 40,
    "status": "OVERDUE",
    "statusText": "Hearing Adjournment Expired",
    "photoUrl": CAMPUS_PLACEHOLDER_SVG,
    "labPhotoUrl": "https://images.unsplash.com/photo-1581092580497-e0d23cbdf1dc?auto=format&fit=crop&w=1200&q=85",
    "blueprintUrl": BLUEPRINT_PLACEHOLDER_SVG,
    "geoCoords": "26.138° N, 85.385° E",
    "labDetails": "Foundry & Thermal Power Testing Lab",
    "officer": {
      "name": "Shri Alok Kumar Jha",
      "role": "Regional Officer",
      "avatar": "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=150&q=80"
    },
    "metrics": {
      "carpetArea": {
        "verified": 4050,
        "required": 4200,
        "unit": "sq.m",
        "ok": false
      },
      "fsr": {
        "actual": "1:19.2",
        "required": "1:15",
        "ok": false
      },
      "fireNoc": {
        "validUntil": "10 Feb 2026",
        "ok": false,
        "label": "Expired 2 Weeks Ago"
      },
      "landTitle": {
        "registered": true,
        "ok": true,
        "label": "Govt Allotment 1954"
      },
      "jointFdr": {
        "amount": "₹1.00 Crore",
        "ok": true,
        "label": "State Bank of India FDR"
      }
    },
    "statusColor": "vermilion",
    "stampLabel": "URGENT OVERDUE",
    "auditTrail": [
      {
        "id": "AUDIT-FILE-2026-4103-01",
        "fileId": "FILE-2026-4103",
        "timestamp": "2026-01-20T09:30:00.000Z",
        "dateFormatted": "20 Jan 2026",
        "timeFormatted": "09:30",
        "officer": "Shri Alok Kumar Jha",
        "action": "APPLICATION_INWARD",
        "remark": "Application inward received, processing fees verified, uploaded affidavit registered.",
        "prevHash": "GENESIS_BLOCK_AICTE_REGULATORY_ROOT",
        "hash": "sha256:0a4f89b1c720e3d5"
      },
      {
        "id": "AUDIT-FILE-2026-4103-02",
        "fileId": "FILE-2026-4103",
        "timestamp": "2026-01-28T14:15:00.000Z",
        "dateFormatted": "28 Jan 2026",
        "timeFormatted": "14:15",
        "officer": "Shri Alok Kumar Jha",
        "action": "STAGE_ADVANCE",
        "remark": "Docket moved to Document Scrutiny table. Cross-referencing revenue title and Fire NOC.",
        "prevHash": "sha256:0a4f89b1c720e3d5",
        "hash": "sha256:4b91f0c2e819a374"
      }
    ]
  },
  {
    "id": "FILE-2026-3301",
    "fileNumber": "AICTE/CRO/2026-27/1-7128911",
    "instituteName": "SGSITS Indore",
    "location": "Vallabh Nagar, Indore, Madhya Pradesh",
    "region": "CRO",
    "intake": 600,
    "complianceScore": 100,
    "currentStageId": 5,
    "daysElapsed": 41,
    "totalSlaDays": 45,
    "status": "ON_TRACK",
    "statusText": "EoA Extension Approved",
    "photoUrl": CAMPUS_PLACEHOLDER_SVG,
    "labPhotoUrl": "https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?auto=format&fit=crop&w=1200&q=85",
    "blueprintUrl": BLUEPRINT_PLACEHOLDER_SVG,
    "geoCoords": "22.724° N, 75.871° E",
    "labDetails": "Centre for Microelectronics & MEMS Sensors",
    "officer": {
      "name": "Dr. M. K. Trivedi",
      "role": "Regional Director",
      "avatar": "https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?auto=format&fit=crop&w=150&q=80"
    },
    "metrics": {
      "carpetArea": {
        "verified": 8200,
        "required": 5400,
        "unit": "sq.m",
        "ok": true
      },
      "fsr": {
        "actual": "1:13.5",
        "required": "1:15",
        "ok": true
      },
      "fireNoc": {
        "validUntil": "12 Dec 2027",
        "ok": true,
        "label": "Indore Municipal Fire NOC"
      },
      "landTitle": {
        "registered": true,
        "ok": true,
        "label": "MP Govt Grant (35 Acres)"
      },
      "jointFdr": {
        "amount": "₹1.50 Crore",
        "ok": true,
        "label": "Central Bank of India FDR"
      }
    },
    "statusColor": "pine",
    "stampLabel": "COUNCIL ORDER",
    "auditTrail": [
      {
        "id": "AUDIT-FILE-2026-3301-01",
        "fileId": "FILE-2026-3301",
        "timestamp": "2026-01-20T09:30:00.000Z",
        "dateFormatted": "20 Jan 2026",
        "timeFormatted": "09:30",
        "officer": "Dr. M. K. Trivedi",
        "action": "APPLICATION_INWARD",
        "remark": "Application inward received, processing fees verified, uploaded affidavit registered.",
        "prevHash": "GENESIS_BLOCK_AICTE_REGULATORY_ROOT",
        "hash": "sha256:0a4f89b1c720e3d5"
      },
      {
        "id": "AUDIT-FILE-2026-3301-02",
        "fileId": "FILE-2026-3301",
        "timestamp": "2026-01-28T14:15:00.000Z",
        "dateFormatted": "28 Jan 2026",
        "timeFormatted": "14:15",
        "officer": "Dr. M. K. Trivedi",
        "action": "STAGE_ADVANCE",
        "remark": "Docket moved to Document Scrutiny table. Cross-referencing revenue title and Fire NOC.",
        "prevHash": "sha256:0a4f89b1c720e3d5",
        "hash": "sha256:4b91f0c2e819a374"
      }
    ]
  },
  {
    "id": "FILE-2026-3302",
    "fileNumber": "AICTE/CRO/2026-27/1-7128994",
    "instituteName": "Birla Vishvakarma Mahavidyalaya (BVM)",
    "location": "Vallabh Vidyanagar, Anand, Gujarat",
    "region": "CRO",
    "intake": 540,
    "complianceScore": 100,
    "currentStageId": 2,
    "daysElapsed": 8,
    "totalSlaDays": 14,
    "status": "ON_TRACK",
    "statusText": "Scrutiny Complete",
    "photoUrl": CAMPUS_PLACEHOLDER_SVG,
    "labPhotoUrl": "https://images.unsplash.com/photo-1581092160607-ee22621dd758?auto=format&fit=crop&w=1200&q=85",
    "blueprintUrl": BLUEPRINT_PLACEHOLDER_SVG,
    "geoCoords": "22.553° N, 72.924° E",
    "labDetails": "Structural Earthquake Engineering Simulator",
    "officer": {
      "name": "Shri Pradip Dave",
      "role": "Scrutiny Lead",
      "avatar": "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&w=150&q=80"
    },
    "metrics": {
      "carpetArea": {
        "verified": 7100,
        "required": 4800,
        "unit": "sq.m",
        "ok": true
      },
      "fsr": {
        "actual": "1:14.1",
        "required": "1:15",
        "ok": true
      },
      "fireNoc": {
        "validUntil": "28 Sep 2026",
        "ok": true,
        "label": "Anand Fire Authority NOC"
      },
      "landTitle": {
        "registered": true,
        "ok": true,
        "label": "CVM Trust Registered Land"
      },
      "jointFdr": {
        "amount": "₹1.00 Crore",
        "ok": true,
        "label": "Bank of Baroda FDR"
      }
    },
    "statusColor": "pine",
    "stampLabel": "IN SCRUTINY",
    "auditTrail": [
      {
        "id": "AUDIT-FILE-2026-3302-01",
        "fileId": "FILE-2026-3302",
        "timestamp": "2026-01-20T09:30:00.000Z",
        "dateFormatted": "20 Jan 2026",
        "timeFormatted": "09:30",
        "officer": "Shri Pradip Dave",
        "action": "APPLICATION_INWARD",
        "remark": "Application inward received, processing fees verified, uploaded affidavit registered.",
        "prevHash": "GENESIS_BLOCK_AICTE_REGULATORY_ROOT",
        "hash": "sha256:0a4f89b1c720e3d5"
      },
      {
        "id": "AUDIT-FILE-2026-3302-02",
        "fileId": "FILE-2026-3302",
        "timestamp": "2026-01-28T14:15:00.000Z",
        "dateFormatted": "28 Jan 2026",
        "timeFormatted": "14:15",
        "officer": "Shri Pradip Dave",
        "action": "STAGE_ADVANCE",
        "remark": "Docket moved to Document Scrutiny table. Cross-referencing revenue title and Fire NOC.",
        "prevHash": "sha256:0a4f89b1c720e3d5",
        "hash": "sha256:4b91f0c2e819a374"
      }
    ]
  },
  {
    "id": "FILE-2026-2101",
    "fileNumber": "AICTE/SWRO/2026-27/1-8930114",
    "instituteName": "BMS College of Engineering",
    "location": "Basavanagudi, Bengaluru, Karnataka",
    "region": "SWRO",
    "intake": 720,
    "complianceScore": 100,
    "currentStageId": 5,
    "daysElapsed": 43,
    "totalSlaDays": 45,
    "status": "ON_TRACK",
    "statusText": "EoA Council Order Granted",
    "photoUrl": CAMPUS_PLACEHOLDER_SVG,
    "labPhotoUrl": "https://images.unsplash.com/photo-1517694712202-14dd9538aa97?auto=format&fit=crop&w=1200&q=85",
    "blueprintUrl": BLUEPRINT_PLACEHOLDER_SVG,
    "geoCoords": "12.941° N, 77.565° E",
    "labDetails": "Centre for Aerospace Propulsion & Avionics Computing",
    "officer": {
      "name": "Dr. C. R. Girish",
      "role": "Regional Director",
      "avatar": "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=150&q=80"
    },
    "metrics": {
      "carpetArea": {
        "verified": 10800,
        "required": 7200,
        "unit": "sq.m",
        "ok": true
      },
      "fsr": {
        "actual": "1:13.1",
        "required": "1:15",
        "ok": true
      },
      "fireNoc": {
        "validUntil": "15 Jan 2028",
        "ok": true,
        "label": "BBMP Fire Safety Certificate"
      },
      "landTitle": {
        "registered": true,
        "ok": true,
        "label": "Freehold Trust Title (15 Acres)"
      },
      "jointFdr": {
        "amount": "₹2.00 Crore",
        "ok": true,
        "label": "Canara Bank Joint FDR"
      }
    },
    "statusColor": "pine",
    "stampLabel": "COUNCIL ORDER",
    "auditTrail": [
      {
        "id": "AUDIT-FILE-2026-2101-01",
        "fileId": "FILE-2026-2101",
        "timestamp": "2026-01-20T09:30:00.000Z",
        "dateFormatted": "20 Jan 2026",
        "timeFormatted": "09:30",
        "officer": "Dr. C. R. Girish",
        "action": "APPLICATION_INWARD",
        "remark": "Application inward received, processing fees verified, uploaded affidavit registered.",
        "prevHash": "GENESIS_BLOCK_AICTE_REGULATORY_ROOT",
        "hash": "sha256:0a4f89b1c720e3d5"
      },
      {
        "id": "AUDIT-FILE-2026-2101-02",
        "fileId": "FILE-2026-2101",
        "timestamp": "2026-01-28T14:15:00.000Z",
        "dateFormatted": "28 Jan 2026",
        "timeFormatted": "14:15",
        "officer": "Dr. C. R. Girish",
        "action": "STAGE_ADVANCE",
        "remark": "Docket moved to Document Scrutiny table. Cross-referencing revenue title and Fire NOC.",
        "prevHash": "sha256:0a4f89b1c720e3d5",
        "hash": "sha256:4b91f0c2e819a374"
      }
    ]
  },
  {
    "id": "FILE-2026-2102",
    "fileNumber": "AICTE/SWRO/2026-27/1-8930255",
    "instituteName": "Government Engineering College (GEC)",
    "location": "Ramavarmapuram, Thrissur, Kerala",
    "region": "SWRO",
    "intake": 480,
    "complianceScore": 100,
    "currentStageId": 1,
    "daysElapsed": 6,
    "totalSlaDays": 7,
    "status": "DUE_SOON",
    "statusText": "Fee Deficit Clarification",
    "photoUrl": CAMPUS_PLACEHOLDER_SVG,
    "labPhotoUrl": "https://images.unsplash.com/photo-1581092335397-9583fe92d232?auto=format&fit=crop&w=1200&q=85",
    "blueprintUrl": BLUEPRINT_PLACEHOLDER_SVG,
    "geoCoords": "10.553° N, 76.223° E",
    "labDetails": "Centre of Excellence in Electric Mobility & Drives",
    "officer": {
      "name": "Smt. Shailaja Menon",
      "role": "Accounts Officer",
      "avatar": "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=150&q=80"
    },
    "metrics": {
      "carpetArea": {
        "verified": 6300,
        "required": 4800,
        "unit": "sq.m",
        "ok": true
      },
      "fsr": {
        "actual": "1:14.3",
        "required": "1:15",
        "ok": true
      },
      "fireNoc": {
        "validUntil": "30 Aug 2026",
        "ok": true,
        "label": "Kerala Fire & Rescue Force"
      },
      "landTitle": {
        "registered": true,
        "ok": true,
        "label": "Kerala Govt Freehold (75 Acres)"
      },
      "jointFdr": {
        "amount": "₹1.00 Crore",
        "ok": true,
        "label": "State Bank of India FDR"
      }
    },
    "statusColor": "ochre",
    "stampLabel": "IN SCRUTINY",
    "auditTrail": [
      {
        "id": "AUDIT-FILE-2026-2102-01",
        "fileId": "FILE-2026-2102",
        "timestamp": "2026-01-20T09:30:00.000Z",
        "dateFormatted": "20 Jan 2026",
        "timeFormatted": "09:30",
        "officer": "Smt. Shailaja Menon",
        "action": "APPLICATION_INWARD",
        "remark": "Application inward received, processing fees verified, uploaded affidavit registered.",
        "prevHash": "GENESIS_BLOCK_AICTE_REGULATORY_ROOT",
        "hash": "sha256:0a4f89b1c720e3d5"
      }
    ]
  },
  {
    "id": "FILE-2026-9044",
    "fileNumber": "AICTE/WRO/2026-27/1-4921245",
    "instituteName": "MIT World Peace University (MIT-WPU)",
    "location": "Kothrud, Pune, Maharashtra",
    "region": "WRO",
    "intake": 780,
    "complianceScore": 100,
    "currentStageId": 3,
    "daysElapsed": 25,
    "totalSlaDays": 35,
    "status": "ON_TRACK",
    "statusText": "EVC Inspection Cleared",
    "photoUrl": CAMPUS_PLACEHOLDER_SVG,
    "labPhotoUrl": "https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?auto=format&fit=crop&w=1200&q=85",
    "blueprintUrl": BLUEPRINT_PLACEHOLDER_SVG,
    "geoCoords": "18.517° N, 73.815° E",
    "labDetails": "Centre of Excellence in Drone & Autonomous Vehicles",
    "officer": {
      "name": "Dr. Ramesh S. Kulkarni",
      "role": "Regional Director",
      "avatar": "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=150&q=80"
    },
    "metrics": {
      "carpetArea": {
        "verified": 11400,
        "required": 7800,
        "unit": "sq.m",
        "ok": true
      },
      "fsr": {
        "actual": "1:13.1",
        "required": "1:15",
        "ok": true
      },
      "fireNoc": {
        "validUntil": "14 Jul 2027",
        "ok": true,
        "label": "PMC Fire Department NOC"
      },
      "landTitle": {
        "registered": true,
        "ok": true,
        "label": "MAEER Trust Campus Freehold (65 Acres)"
      },
      "jointFdr": {
        "amount": "₹1.50 Crore",
        "ok": true,
        "label": "Bank of India Joint FDR"
      }
    },
    "statusColor": "pine",
    "stampLabel": "IN SCRUTINY",
    "auditTrail": [
      {
        "id": "AUDIT-FILE-2026-9044-01",
        "fileId": "FILE-2026-9044",
        "timestamp": "2026-01-20T09:30:00.000Z",
        "dateFormatted": "20 Jan 2026",
        "timeFormatted": "09:30",
        "officer": "Dr. Ramesh S. Kulkarni",
        "action": "APPLICATION_INWARD",
        "remark": "Application inward received, processing fees verified, uploaded affidavit registered.",
        "prevHash": "GENESIS_BLOCK_AICTE_REGULATORY_ROOT",
        "hash": "sha256:0a4f89b1c720e3d5"
      },
      {
        "id": "AUDIT-FILE-2026-9044-02",
        "fileId": "FILE-2026-9044",
        "timestamp": "2026-01-28T14:15:00.000Z",
        "dateFormatted": "28 Jan 2026",
        "timeFormatted": "14:15",
        "officer": "Dr. Ramesh S. Kulkarni",
        "action": "STAGE_ADVANCE",
        "remark": "Docket moved to Document Scrutiny table. Cross-referencing revenue title and Fire NOC.",
        "prevHash": "sha256:0a4f89b1c720e3d5",
        "hash": "sha256:4b91f0c2e819a374"
      }
    ]
  },
  {
    "id": "FILE-2026-9045",
    "fileNumber": "AICTE/WRO/2026-27/1-4921312",
    "instituteName": "Sardar Patel Institute of Technology (SPIT)",
    "location": "Andheri West, Mumbai, Maharashtra",
    "region": "WRO",
    "intake": 480,
    "complianceScore": 100,
    "currentStageId": 5,
    "daysElapsed": 42,
    "totalSlaDays": 45,
    "status": "ON_TRACK",
    "statusText": "Autonomous Council Order",
    "photoUrl": CAMPUS_PLACEHOLDER_SVG,
    "labPhotoUrl": "https://images.unsplash.com/photo-1517694712202-14dd9538aa97?auto=format&fit=crop&w=1200&q=85",
    "blueprintUrl": BLUEPRINT_PLACEHOLDER_SVG,
    "geoCoords": "19.123° N, 72.836° E",
    "labDetails": "Wireless IoT & Telematics Engineering Centre",
    "officer": {
      "name": "Dr. Ramesh S. Kulkarni",
      "role": "Regional Director",
      "avatar": "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=150&q=80"
    },
    "metrics": {
      "carpetArea": {
        "verified": 7900,
        "required": 4800,
        "unit": "sq.m",
        "ok": true
      },
      "fsr": {
        "actual": "1:12.8",
        "required": "1:15",
        "ok": true
      },
      "fireNoc": {
        "validUntil": "29 Nov 2027",
        "ok": true,
        "label": "Mumbai Fire Brigade Cleared"
      },
      "landTitle": {
        "registered": true,
        "ok": true,
        "label": "Bharatiya Vidya Bhavan Campus"
      },
      "jointFdr": {
        "amount": "₹1.00 Crore",
        "ok": true,
        "label": "State Bank of India FDR"
      }
    },
    "statusColor": "pine",
    "stampLabel": "COUNCIL ORDER",
    "auditTrail": [
      {
        "id": "AUDIT-FILE-2026-9045-01",
        "fileId": "FILE-2026-9045",
        "timestamp": "2026-01-20T09:30:00.000Z",
        "dateFormatted": "20 Jan 2026",
        "timeFormatted": "09:30",
        "officer": "Dr. Ramesh S. Kulkarni",
        "action": "APPLICATION_INWARD",
        "remark": "Application inward received, processing fees verified, uploaded affidavit registered.",
        "prevHash": "GENESIS_BLOCK_AICTE_REGULATORY_ROOT",
        "hash": "sha256:0a4f89b1c720e3d5"
      },
      {
        "id": "AUDIT-FILE-2026-9045-02",
        "fileId": "FILE-2026-9045",
        "timestamp": "2026-01-28T14:15:00.000Z",
        "dateFormatted": "28 Jan 2026",
        "timeFormatted": "14:15",
        "officer": "Dr. Ramesh S. Kulkarni",
        "action": "STAGE_ADVANCE",
        "remark": "Docket moved to Document Scrutiny table. Cross-referencing revenue title and Fire NOC.",
        "prevHash": "sha256:0a4f89b1c720e3d5",
        "hash": "sha256:4b91f0c2e819a374"
      }
    ]
  },
  {
    "id": "FILE-2026-9046",
    "fileNumber": "AICTE/WRO/2026-27/1-4921405",
    "instituteName": "Goa College of Engineering (GEC)",
    "location": "Farmagudi, Ponda, Goa",
    "region": "WRO",
    "intake": 360,
    "complianceScore": 100,
    "currentStageId": 2,
    "daysElapsed": 12,
    "totalSlaDays": 14,
    "status": "DUE_SOON",
    "statusText": "Doc Scrutiny in 2 Days",
    "photoUrl": CAMPUS_PLACEHOLDER_SVG,
    "labPhotoUrl": "https://images.unsplash.com/photo-1581092795360-fd1ca04f0952?auto=format&fit=crop&w=1200&q=85",
    "blueprintUrl": BLUEPRINT_PLACEHOLDER_SVG,
    "geoCoords": "15.424° N, 74.008° E",
    "labDetails": "Marine Structural Dynamics & Coastal Testing Lab",
    "officer": {
      "name": "Smt. Archana Varma",
      "role": "Scrutiny Officer",
      "avatar": "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=150&q=80"
    },
    "metrics": {
      "carpetArea": {
        "verified": 5600,
        "required": 4200,
        "unit": "sq.m",
        "ok": true
      },
      "fsr": {
        "actual": "1:14.2",
        "required": "1:15",
        "ok": true
      },
      "fireNoc": {
        "validUntil": "15 Jun 2026",
        "ok": true,
        "label": "Goa Fire & Emergency Services"
      },
      "landTitle": {
        "registered": true,
        "ok": true,
        "label": "Govt of Goa Allotment (280 Acres)"
      },
      "jointFdr": {
        "amount": "₹1.00 Crore",
        "ok": true,
        "label": "State Bank of India FDR"
      }
    },
    "statusColor": "ochre",
    "stampLabel": "IN SCRUTINY",
    "auditTrail": [
      {
        "id": "AUDIT-FILE-2026-9046-01",
        "fileId": "FILE-2026-9046",
        "timestamp": "2026-01-20T09:30:00.000Z",
        "dateFormatted": "20 Jan 2026",
        "timeFormatted": "09:30",
        "officer": "Smt. Archana Varma",
        "action": "APPLICATION_INWARD",
        "remark": "Application inward received, processing fees verified, uploaded affidavit registered.",
        "prevHash": "GENESIS_BLOCK_AICTE_REGULATORY_ROOT",
        "hash": "sha256:0a4f89b1c720e3d5"
      },
      {
        "id": "AUDIT-FILE-2026-9046-02",
        "fileId": "FILE-2026-9046",
        "timestamp": "2026-01-28T14:15:00.000Z",
        "dateFormatted": "28 Jan 2026",
        "timeFormatted": "14:15",
        "officer": "Smt. Archana Varma",
        "action": "STAGE_ADVANCE",
        "remark": "Docket moved to Document Scrutiny table. Cross-referencing revenue title and Fire NOC.",
        "prevHash": "sha256:0a4f89b1c720e3d5",
        "hash": "sha256:4b91f0c2e819a374"
      }
    ]
  },
  {
    "id": "FILE-2026-8815",
    "fileNumber": "AICTE/NRO/2026-27/1-3829350",
    "instituteName": "Motilal Nehru National Institute of Tech (MNNIT)",
    "location": "Teliarganj, Prayagraj, Uttar Pradesh",
    "region": "NRO",
    "intake": 840,
    "complianceScore": 100,
    "currentStageId": 5,
    "daysElapsed": 44,
    "totalSlaDays": 45,
    "status": "ON_TRACK",
    "statusText": "Council Order Granted",
    "photoUrl": CAMPUS_PLACEHOLDER_SVG,
    "labPhotoUrl": "https://images.unsplash.com/photo-1558494949-ef010cbdcc31?auto=format&fit=crop&w=1200&q=85",
    "blueprintUrl": BLUEPRINT_PLACEHOLDER_SVG,
    "geoCoords": "25.493° N, 81.863° E",
    "labDetails": "National Cyber-Physical Security & Supercomputing Node",
    "officer": {
      "name": "Prof. D. K. Sharma",
      "role": "EVC Convener",
      "avatar": "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=150&q=80"
    },
    "metrics": {
      "carpetArea": {
        "verified": 14200,
        "required": 8400,
        "unit": "sq.m",
        "ok": true
      },
      "fsr": {
        "actual": "1:11.9",
        "required": "1:15",
        "ok": true
      },
      "fireNoc": {
        "validUntil": "18 Dec 2027",
        "ok": true,
        "label": "UP Fire Services Clearance"
      },
      "landTitle": {
        "registered": true,
        "ok": true,
        "label": "National Institute Campus (222 Acres)"
      },
      "jointFdr": {
        "amount": "₹2.00 Crore",
        "ok": true,
        "label": "State Bank of India FDR"
      }
    },
    "statusColor": "pine",
    "stampLabel": "COUNCIL ORDER",
    "auditTrail": [
      {
        "id": "AUDIT-FILE-2026-8815-01",
        "fileId": "FILE-2026-8815",
        "timestamp": "2026-01-20T09:30:00.000Z",
        "dateFormatted": "20 Jan 2026",
        "timeFormatted": "09:30",
        "officer": "Prof. D. K. Sharma",
        "action": "APPLICATION_INWARD",
        "remark": "Application inward received, processing fees verified, uploaded affidavit registered.",
        "prevHash": "GENESIS_BLOCK_AICTE_REGULATORY_ROOT",
        "hash": "sha256:0a4f89b1c720e3d5"
      },
      {
        "id": "AUDIT-FILE-2026-8815-02",
        "fileId": "FILE-2026-8815",
        "timestamp": "2026-01-28T14:15:00.000Z",
        "dateFormatted": "28 Jan 2026",
        "timeFormatted": "14:15",
        "officer": "Prof. D. K. Sharma",
        "action": "STAGE_ADVANCE",
        "remark": "Docket moved to Document Scrutiny table. Cross-referencing revenue title and Fire NOC.",
        "prevHash": "sha256:0a4f89b1c720e3d5",
        "hash": "sha256:4b91f0c2e819a374"
      }
    ]
  },
  {
    "id": "FILE-2026-8816",
    "fileNumber": "AICTE/NRO/2026-27/1-3829410",
    "instituteName": "Madan Mohan Malaviya Univ of Tech (MMMUT)",
    "location": "Gorakhpur, Uttar Pradesh",
    "region": "NRO",
    "intake": 600,
    "complianceScore": 100,
    "currentStageId": 3,
    "daysElapsed": 28,
    "totalSlaDays": 35,
    "status": "DUE_SOON",
    "statusText": "EVC Closes in 3 Days",
    "photoUrl": CAMPUS_PLACEHOLDER_SVG,
    "labPhotoUrl": "https://images.unsplash.com/photo-1581092335397-9583fe92d232?auto=format&fit=crop&w=1200&q=85",
    "blueprintUrl": BLUEPRINT_PLACEHOLDER_SVG,
    "geoCoords": "26.731° N, 83.433° E",
    "labDetails": "Smart Energy Grid & Transmission Testing Lab",
    "officer": {
      "name": "Shri S. P. Shukla",
      "role": "Accounts Section Officer",
      "avatar": "https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?auto=format&fit=crop&w=150&q=80"
    },
    "metrics": {
      "carpetArea": {
        "verified": 8800,
        "required": 5400,
        "unit": "sq.m",
        "ok": true
      },
      "fsr": {
        "actual": "1:14.0",
        "required": "1:15",
        "ok": true
      },
      "fireNoc": {
        "validUntil": "11 Sep 2026",
        "ok": true,
        "label": "Gorakhpur Municipal Fire NOC"
      },
      "landTitle": {
        "registered": true,
        "ok": true,
        "label": "State Technical Univ Freehold"
      },
      "jointFdr": {
        "amount": "₹1.20 Crore",
        "ok": true,
        "label": "Punjab National Bank FDR"
      }
    },
    "statusColor": "ochre",
    "stampLabel": "IN SCRUTINY",
    "auditTrail": [
      {
        "id": "AUDIT-FILE-2026-8816-01",
        "fileId": "FILE-2026-8816",
        "timestamp": "2026-01-20T09:30:00.000Z",
        "dateFormatted": "20 Jan 2026",
        "timeFormatted": "09:30",
        "officer": "Shri S. P. Shukla",
        "action": "APPLICATION_INWARD",
        "remark": "Application inward received, processing fees verified, uploaded affidavit registered.",
        "prevHash": "GENESIS_BLOCK_AICTE_REGULATORY_ROOT",
        "hash": "sha256:0a4f89b1c720e3d5"
      },
      {
        "id": "AUDIT-FILE-2026-8816-02",
        "fileId": "FILE-2026-8816",
        "timestamp": "2026-01-28T14:15:00.000Z",
        "dateFormatted": "28 Jan 2026",
        "timeFormatted": "14:15",
        "officer": "Shri S. P. Shukla",
        "action": "STAGE_ADVANCE",
        "remark": "Docket moved to Document Scrutiny table. Cross-referencing revenue title and Fire NOC.",
        "prevHash": "sha256:0a4f89b1c720e3d5",
        "hash": "sha256:4b91f0c2e819a374"
      }
    ]
  },
  {
    "id": "FILE-2026-6522",
    "fileNumber": "AICTE/NWRO/2026-27/1-2919012",
    "instituteName": "Indraprastha Institute of Information Tech (IIIT-Delhi)",
    "location": "Okhla Phase III, New Delhi",
    "region": "NWRO",
    "intake": 540,
    "complianceScore": 100,
    "currentStageId": 5,
    "daysElapsed": 43,
    "totalSlaDays": 45,
    "status": "ON_TRACK",
    "statusText": "Council Order Granted",
    "photoUrl": CAMPUS_PLACEHOLDER_SVG,
    "labPhotoUrl": "https://images.unsplash.com/photo-1517694712202-14dd9538aa97?auto=format&fit=crop&w=1200&q=85",
    "blueprintUrl": BLUEPRINT_PLACEHOLDER_SVG,
    "geoCoords": "28.544° N, 77.272° E",
    "labDetails": "Artificial Intelligence & Human Centered Design Lab",
    "officer": {
      "name": "Shri Rajiv Bajaj",
      "role": "Regional Officer",
      "avatar": "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&w=150&q=80"
    },
    "metrics": {
      "carpetArea": {
        "verified": 9400,
        "required": 5400,
        "unit": "sq.m",
        "ok": true
      },
      "fsr": {
        "actual": "1:11.5",
        "required": "1:15",
        "ok": true
      },
      "fireNoc": {
        "validUntil": "24 Nov 2027",
        "ok": true,
        "label": "Delhi Fire Service NOC"
      },
      "landTitle": {
        "registered": true,
        "ok": true,
        "label": "Govt of NCT Delhi State Land"
      },
      "jointFdr": {
        "amount": "₹2.00 Crore",
        "ok": true,
        "label": "State Bank of India FDR"
      }
    },
    "statusColor": "pine",
    "stampLabel": "COUNCIL ORDER",
    "auditTrail": [
      {
        "id": "AUDIT-FILE-2026-6522-01",
        "fileId": "FILE-2026-6522",
        "timestamp": "2026-01-20T09:30:00.000Z",
        "dateFormatted": "20 Jan 2026",
        "timeFormatted": "09:30",
        "officer": "Shri Rajiv Bajaj",
        "action": "APPLICATION_INWARD",
        "remark": "Application inward received, processing fees verified, uploaded affidavit registered.",
        "prevHash": "GENESIS_BLOCK_AICTE_REGULATORY_ROOT",
        "hash": "sha256:0a4f89b1c720e3d5"
      },
      {
        "id": "AUDIT-FILE-2026-6522-02",
        "fileId": "FILE-2026-6522",
        "timestamp": "2026-01-28T14:15:00.000Z",
        "dateFormatted": "28 Jan 2026",
        "timeFormatted": "14:15",
        "officer": "Shri Rajiv Bajaj",
        "action": "STAGE_ADVANCE",
        "remark": "Docket moved to Document Scrutiny table. Cross-referencing revenue title and Fire NOC.",
        "prevHash": "sha256:0a4f89b1c720e3d5",
        "hash": "sha256:4b91f0c2e819a374"
      }
    ]
  },
  {
    "id": "FILE-2026-6523",
    "fileNumber": "AICTE/NWRO/2026-27/1-2919105",
    "instituteName": "Punjab Engineering College (PEC)",
    "location": "Sector 12, Chandigarh",
    "region": "NWRO",
    "intake": 720,
    "complianceScore": 100,
    "currentStageId": 3,
    "daysElapsed": 26,
    "totalSlaDays": 35,
    "status": "ON_TRACK",
    "statusText": "Physical Inspection Passed",
    "photoUrl": CAMPUS_PLACEHOLDER_SVG,
    "labPhotoUrl": "https://images.unsplash.com/photo-1581092160607-ee22621dd758?auto=format&fit=crop&w=1200&q=85",
    "blueprintUrl": BLUEPRINT_PLACEHOLDER_SVG,
    "geoCoords": "30.766° N, 76.786° E",
    "labDetails": "Aerospace Aerodynamics Subsonic Wind Tunnel Facility",
    "officer": {
      "name": "Prof. Harpreet Singh",
      "role": "EVC Team Lead",
      "avatar": "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=150&q=80"
    },
    "metrics": {
      "carpetArea": {
        "verified": 11200,
        "required": 7200,
        "unit": "sq.m",
        "ok": true
      },
      "fsr": {
        "actual": "1:12.7",
        "required": "1:15",
        "ok": true
      },
      "fireNoc": {
        "validUntil": "15 Oct 2027",
        "ok": true,
        "label": "Chandigarh Fire Dept Clearance"
      },
      "landTitle": {
        "registered": true,
        "ok": true,
        "label": "Deemed University Campus (146 Acres)"
      },
      "jointFdr": {
        "amount": "₹1.50 Crore",
        "ok": true,
        "label": "Punjab National Bank FDR"
      }
    },
    "statusColor": "pine",
    "stampLabel": "IN SCRUTINY",
    "auditTrail": [
      {
        "id": "AUDIT-FILE-2026-6523-01",
        "fileId": "FILE-2026-6523",
        "timestamp": "2026-01-20T09:30:00.000Z",
        "dateFormatted": "20 Jan 2026",
        "timeFormatted": "09:30",
        "officer": "Prof. Harpreet Singh",
        "action": "APPLICATION_INWARD",
        "remark": "Application inward received, processing fees verified, uploaded affidavit registered.",
        "prevHash": "GENESIS_BLOCK_AICTE_REGULATORY_ROOT",
        "hash": "sha256:0a4f89b1c720e3d5"
      },
      {
        "id": "AUDIT-FILE-2026-6523-02",
        "fileId": "FILE-2026-6523",
        "timestamp": "2026-01-28T14:15:00.000Z",
        "dateFormatted": "28 Jan 2026",
        "timeFormatted": "14:15",
        "officer": "Prof. Harpreet Singh",
        "action": "STAGE_ADVANCE",
        "remark": "Docket moved to Document Scrutiny table. Cross-referencing revenue title and Fire NOC.",
        "prevHash": "sha256:0a4f89b1c720e3d5",
        "hash": "sha256:4b91f0c2e819a374"
      }
    ]
  },
  {
    "id": "FILE-2026-5204",
    "fileNumber": "AICTE/SCRO/2026-27/1-4191024",
    "instituteName": "VNR Vignana Jyothi Inst of Engg & Tech",
    "location": "Bachupally, Hyderabad, Telangana",
    "region": "SCRO",
    "intake": 780,
    "complianceScore": 100,
    "currentStageId": 5,
    "daysElapsed": 44,
    "totalSlaDays": 45,
    "status": "ON_TRACK",
    "statusText": "EoA Council Order Issued",
    "photoUrl": CAMPUS_PLACEHOLDER_SVG,
    "labPhotoUrl": "https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?auto=format&fit=crop&w=1200&q=85",
    "blueprintUrl": BLUEPRINT_PLACEHOLDER_SVG,
    "geoCoords": "17.538° N, 78.384° E",
    "labDetails": "Industrial Automation & Cognitive Robotics Center",
    "officer": {
      "name": "Dr. B. K. Murthy",
      "role": "Member Secretary",
      "avatar": "https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?auto=format&fit=crop&w=150&q=80"
    },
    "metrics": {
      "carpetArea": {
        "verified": 10800,
        "required": 7800,
        "unit": "sq.m",
        "ok": true
      },
      "fsr": {
        "actual": "1:13.2",
        "required": "1:15",
        "ok": true
      },
      "fireNoc": {
        "validUntil": "18 Dec 2027",
        "ok": true,
        "label": "Telangana Disaster NOC"
      },
      "landTitle": {
        "registered": true,
        "ok": true,
        "label": "Vignana Jyothi Society Freehold"
      },
      "jointFdr": {
        "amount": "₹1.50 Crore",
        "ok": true,
        "label": "Union Bank of India FDR"
      }
    },
    "statusColor": "pine",
    "stampLabel": "COUNCIL ORDER",
    "auditTrail": [
      {
        "id": "AUDIT-FILE-2026-5204-01",
        "fileId": "FILE-2026-5204",
        "timestamp": "2026-01-20T09:30:00.000Z",
        "dateFormatted": "20 Jan 2026",
        "timeFormatted": "09:30",
        "officer": "Dr. B. K. Murthy",
        "action": "APPLICATION_INWARD",
        "remark": "Application inward received, processing fees verified, uploaded affidavit registered.",
        "prevHash": "GENESIS_BLOCK_AICTE_REGULATORY_ROOT",
        "hash": "sha256:0a4f89b1c720e3d5"
      },
      {
        "id": "AUDIT-FILE-2026-5204-02",
        "fileId": "FILE-2026-5204",
        "timestamp": "2026-01-28T14:15:00.000Z",
        "dateFormatted": "28 Jan 2026",
        "timeFormatted": "14:15",
        "officer": "Dr. B. K. Murthy",
        "action": "STAGE_ADVANCE",
        "remark": "Docket moved to Document Scrutiny table. Cross-referencing revenue title and Fire NOC.",
        "prevHash": "sha256:0a4f89b1c720e3d5",
        "hash": "sha256:4b91f0c2e819a374"
      }
    ]
  },
  {
    "id": "FILE-2026-5205",
    "fileNumber": "AICTE/SCRO/2026-27/1-4191130",
    "instituteName": "G. Pulla Reddy Engineering College",
    "location": "Kurnool, Andhra Pradesh",
    "region": "SCRO",
    "intake": 540,
    "complianceScore": 100,
    "currentStageId": 3,
    "daysElapsed": 27,
    "totalSlaDays": 35,
    "status": "DUE_SOON",
    "statusText": "EVC Closes in 2 Days",
    "photoUrl": CAMPUS_PLACEHOLDER_SVG,
    "labPhotoUrl": "https://images.unsplash.com/photo-1581092162384-8987c1d64718?auto=format&fit=crop&w=1200&q=85",
    "blueprintUrl": BLUEPRINT_PLACEHOLDER_SVG,
    "geoCoords": "15.828° N, 78.037° E",
    "labDetails": "Embedded Systems & High-Speed VLSI Design Lab",
    "officer": {
      "name": "Shri P. Satyanarayana",
      "role": "Academic Scrutinizer",
      "avatar": "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&w=150&q=80"
    },
    "metrics": {
      "carpetArea": {
        "verified": 7400,
        "required": 5400,
        "unit": "sq.m",
        "ok": true
      },
      "fsr": {
        "actual": "1:13.9",
        "required": "1:15",
        "ok": true
      },
      "fireNoc": {
        "validUntil": "20 Nov 2026",
        "ok": true,
        "label": "AP State Disaster NOC"
      },
      "landTitle": {
        "registered": true,
        "ok": true,
        "label": "G. Pulla Reddy Charities Deed"
      },
      "jointFdr": {
        "amount": "₹1.00 Crore",
        "ok": true,
        "label": "Andhra Bank FDR"
      }
    },
    "statusColor": "ochre",
    "stampLabel": "IN SCRUTINY",
    "auditTrail": [
      {
        "id": "AUDIT-FILE-2026-5205-01",
        "fileId": "FILE-2026-5205",
        "timestamp": "2026-01-20T09:30:00.000Z",
        "dateFormatted": "20 Jan 2026",
        "timeFormatted": "09:30",
        "officer": "Shri P. Satyanarayana",
        "action": "APPLICATION_INWARD",
        "remark": "Application inward received, processing fees verified, uploaded affidavit registered.",
        "prevHash": "GENESIS_BLOCK_AICTE_REGULATORY_ROOT",
        "hash": "sha256:0a4f89b1c720e3d5"
      },
      {
        "id": "AUDIT-FILE-2026-5205-02",
        "fileId": "FILE-2026-5205",
        "timestamp": "2026-01-28T14:15:00.000Z",
        "dateFormatted": "28 Jan 2026",
        "timeFormatted": "14:15",
        "officer": "Shri P. Satyanarayana",
        "action": "STAGE_ADVANCE",
        "remark": "Docket moved to Document Scrutiny table. Cross-referencing revenue title and Fire NOC.",
        "prevHash": "sha256:0a4f89b1c720e3d5",
        "hash": "sha256:4b91f0c2e819a374"
      }
    ]
  },
  {
    "id": "FILE-2026-4104",
    "fileNumber": "AICTE/ERO/2026-27/1-6019550",
    "instituteName": "Jadavpur University Faculty of Engineering",
    "location": "Jadavpur, Kolkata, West Bengal",
    "region": "ERO",
    "intake": 840,
    "complianceScore": 100,
    "currentStageId": 5,
    "daysElapsed": 41,
    "totalSlaDays": 45,
    "status": "ON_TRACK",
    "statusText": "Council Order Issued",
    "photoUrl": CAMPUS_PLACEHOLDER_SVG,
    "labPhotoUrl": "https://images.unsplash.com/photo-1581092335397-9583fe92d232?auto=format&fit=crop&w=1200&q=85",
    "blueprintUrl": BLUEPRINT_PLACEHOLDER_SVG,
    "geoCoords": "22.498° N, 88.371° E",
    "labDetails": "National High Voltage & Nanotechnology Lab",
    "officer": {
      "name": "Dr. Subir Banerjee",
      "role": "EVC Convener",
      "avatar": "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=150&q=80"
    },
    "metrics": {
      "carpetArea": {
        "verified": 14800,
        "required": 8400,
        "unit": "sq.m",
        "ok": true
      },
      "fsr": {
        "actual": "1:11.8",
        "required": "1:15",
        "ok": true
      },
      "fireNoc": {
        "validUntil": "15 Oct 2027",
        "ok": true,
        "label": "WB Fire Services Cleared"
      },
      "landTitle": {
        "registered": true,
        "ok": true,
        "label": "State Autonomous Campus (58 Acres)"
      },
      "jointFdr": {
        "amount": "₹2.00 Crore",
        "ok": true,
        "label": "State Bank of India FDR"
      }
    },
    "statusColor": "pine",
    "stampLabel": "COUNCIL ORDER",
    "auditTrail": [
      {
        "id": "AUDIT-FILE-2026-4104-01",
        "fileId": "FILE-2026-4104",
        "timestamp": "2026-01-20T09:30:00.000Z",
        "dateFormatted": "20 Jan 2026",
        "timeFormatted": "09:30",
        "officer": "Dr. Subir Banerjee",
        "action": "APPLICATION_INWARD",
        "remark": "Application inward received, processing fees verified, uploaded affidavit registered.",
        "prevHash": "GENESIS_BLOCK_AICTE_REGULATORY_ROOT",
        "hash": "sha256:0a4f89b1c720e3d5"
      },
      {
        "id": "AUDIT-FILE-2026-4104-02",
        "fileId": "FILE-2026-4104",
        "timestamp": "2026-01-28T14:15:00.000Z",
        "dateFormatted": "28 Jan 2026",
        "timeFormatted": "14:15",
        "officer": "Dr. Subir Banerjee",
        "action": "STAGE_ADVANCE",
        "remark": "Docket moved to Document Scrutiny table. Cross-referencing revenue title and Fire NOC.",
        "prevHash": "sha256:0a4f89b1c720e3d5",
        "hash": "sha256:4b91f0c2e819a374"
      }
    ]
  },
  {
    "id": "FILE-2026-4105",
    "fileNumber": "AICTE/ERO/2026-27/1-6019622",
    "instituteName": "Birla Institute of Technology (BIT Mesra)",
    "location": "Mesra, Ranchi, Jharkhand",
    "region": "ERO",
    "intake": 720,
    "complianceScore": 100,
    "currentStageId": 3,
    "daysElapsed": 26,
    "totalSlaDays": 35,
    "status": "ON_TRACK",
    "statusText": "Physical Lab Passed",
    "photoUrl": CAMPUS_PLACEHOLDER_SVG,
    "labPhotoUrl": "https://images.unsplash.com/photo-1581092580497-e0d23cbdf1dc?auto=format&fit=crop&w=1200&q=85",
    "blueprintUrl": BLUEPRINT_PLACEHOLDER_SVG,
    "geoCoords": "23.412° N, 85.439° E",
    "labDetails": "Rocketry & Space Propellant Test Facility",
    "officer": {
      "name": "Dr. Subir Banerjee",
      "role": "EVC Convener",
      "avatar": "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=150&q=80"
    },
    "metrics": {
      "carpetArea": {
        "verified": 12200,
        "required": 7200,
        "unit": "sq.m",
        "ok": true
      },
      "fsr": {
        "actual": "1:12.6",
        "required": "1:15",
        "ok": true
      },
      "fireNoc": {
        "validUntil": "12 Dec 2026",
        "ok": true,
        "label": "Jharkhand Fire Service NOC"
      },
      "landTitle": {
        "registered": true,
        "ok": true,
        "label": "Deemed University Campus (780 Acres)"
      },
      "jointFdr": {
        "amount": "₹1.50 Crore",
        "ok": true,
        "label": "UCO Bank Joint FDR"
      }
    },
    "statusColor": "pine",
    "stampLabel": "IN SCRUTINY",
    "auditTrail": [
      {
        "id": "AUDIT-FILE-2026-4105-01",
        "fileId": "FILE-2026-4105",
        "timestamp": "2026-01-20T09:30:00.000Z",
        "dateFormatted": "20 Jan 2026",
        "timeFormatted": "09:30",
        "officer": "Dr. Subir Banerjee",
        "action": "APPLICATION_INWARD",
        "remark": "Application inward received, processing fees verified, uploaded affidavit registered.",
        "prevHash": "GENESIS_BLOCK_AICTE_REGULATORY_ROOT",
        "hash": "sha256:0a4f89b1c720e3d5"
      },
      {
        "id": "AUDIT-FILE-2026-4105-02",
        "fileId": "FILE-2026-4105",
        "timestamp": "2026-01-28T14:15:00.000Z",
        "dateFormatted": "28 Jan 2026",
        "timeFormatted": "14:15",
        "officer": "Dr. Subir Banerjee",
        "action": "STAGE_ADVANCE",
        "remark": "Docket moved to Document Scrutiny table. Cross-referencing revenue title and Fire NOC.",
        "prevHash": "sha256:0a4f89b1c720e3d5",
        "hash": "sha256:4b91f0c2e819a374"
      }
    ]
  },
  {
    "id": "FILE-2026-3303",
    "fileNumber": "AICTE/CRO/2026-27/1-7129105",
    "instituteName": "Maulana Azad National Inst of Tech (MANIT)",
    "location": "Link Road Number 3, Bhopal, Madhya Pradesh",
    "region": "CRO",
    "intake": 840,
    "complianceScore": 100,
    "currentStageId": 5,
    "daysElapsed": 43,
    "totalSlaDays": 45,
    "status": "ON_TRACK",
    "statusText": "Council Order Approved",
    "photoUrl": CAMPUS_PLACEHOLDER_SVG,
    "labPhotoUrl": "https://images.unsplash.com/photo-1581092335397-9583fe92d232?auto=format&fit=crop&w=1200&q=85",
    "blueprintUrl": BLUEPRINT_PLACEHOLDER_SVG,
    "geoCoords": "23.214° N, 77.404° E",
    "labDetails": "Advanced Energy Systems & National Power Grid Lab",
    "officer": {
      "name": "Dr. M. K. Trivedi",
      "role": "Regional Director",
      "avatar": "https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?auto=format&fit=crop&w=150&q=80"
    },
    "metrics": {
      "carpetArea": {
        "verified": 13600,
        "required": 8400,
        "unit": "sq.m",
        "ok": true
      },
      "fsr": {
        "actual": "1:12.1",
        "required": "1:15",
        "ok": true
      },
      "fireNoc": {
        "validUntil": "19 Nov 2027",
        "ok": true,
        "label": "Bhopal Municipal Fire NOC"
      },
      "landTitle": {
        "registered": true,
        "ok": true,
        "label": "NIT Campus Freehold (650 Acres)"
      },
      "jointFdr": {
        "amount": "₹2.00 Crore",
        "ok": true,
        "label": "State Bank of India FDR"
      }
    },
    "statusColor": "pine",
    "stampLabel": "COUNCIL ORDER",
    "auditTrail": [
      {
        "id": "AUDIT-FILE-2026-3303-01",
        "fileId": "FILE-2026-3303",
        "timestamp": "2026-01-20T09:30:00.000Z",
        "dateFormatted": "20 Jan 2026",
        "timeFormatted": "09:30",
        "officer": "Dr. M. K. Trivedi",
        "action": "APPLICATION_INWARD",
        "remark": "Application inward received, processing fees verified, uploaded affidavit registered.",
        "prevHash": "GENESIS_BLOCK_AICTE_REGULATORY_ROOT",
        "hash": "sha256:0a4f89b1c720e3d5"
      },
      {
        "id": "AUDIT-FILE-2026-3303-02",
        "fileId": "FILE-2026-3303",
        "timestamp": "2026-01-28T14:15:00.000Z",
        "dateFormatted": "28 Jan 2026",
        "timeFormatted": "14:15",
        "officer": "Dr. M. K. Trivedi",
        "action": "STAGE_ADVANCE",
        "remark": "Docket moved to Document Scrutiny table. Cross-referencing revenue title and Fire NOC.",
        "prevHash": "sha256:0a4f89b1c720e3d5",
        "hash": "sha256:4b91f0c2e819a374"
      }
    ]
  },
  {
    "id": "FILE-2026-3304",
    "fileNumber": "AICTE/CRO/2026-27/1-7129218",
    "instituteName": "Dharmsinh Desai University (DDU)",
    "location": "College Road, Nadiad, Gujarat",
    "region": "CRO",
    "intake": 600,
    "complianceScore": 100,
    "currentStageId": 3,
    "daysElapsed": 25,
    "totalSlaDays": 35,
    "status": "DUE_SOON",
    "statusText": "EVC Closes in 2 Days",
    "photoUrl": CAMPUS_PLACEHOLDER_SVG,
    "labPhotoUrl": "https://images.unsplash.com/photo-1532094349884-543bc11b234d?auto=format&fit=crop&w=1200&q=85",
    "blueprintUrl": BLUEPRINT_PLACEHOLDER_SVG,
    "geoCoords": "22.691° N, 72.863° E",
    "labDetails": "Chemical Process Instrumentation & Petrochemical Lab",
    "officer": {
      "name": "Shri Pradip Dave",
      "role": "Scrutiny Lead",
      "avatar": "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&w=150&q=80"
    },
    "metrics": {
      "carpetArea": {
        "verified": 8200,
        "required": 5400,
        "unit": "sq.m",
        "ok": true
      },
      "fsr": {
        "actual": "1:13.8",
        "required": "1:15",
        "ok": true
      },
      "fireNoc": {
        "validUntil": "15 Aug 2026",
        "ok": true,
        "label": "Gujarat Fire Authority NOC"
      },
      "landTitle": {
        "registered": true,
        "ok": true,
        "label": "DDU Foundation Registered Land"
      },
      "jointFdr": {
        "amount": "₹1.00 Crore",
        "ok": true,
        "label": "Bank of Baroda FDR"
      }
    },
    "statusColor": "ochre",
    "stampLabel": "IN SCRUTINY",
    "auditTrail": [
      {
        "id": "AUDIT-FILE-2026-3304-01",
        "fileId": "FILE-2026-3304",
        "timestamp": "2026-01-20T09:30:00.000Z",
        "dateFormatted": "20 Jan 2026",
        "timeFormatted": "09:30",
        "officer": "Shri Pradip Dave",
        "action": "APPLICATION_INWARD",
        "remark": "Application inward received, processing fees verified, uploaded affidavit registered.",
        "prevHash": "GENESIS_BLOCK_AICTE_REGULATORY_ROOT",
        "hash": "sha256:0a4f89b1c720e3d5"
      },
      {
        "id": "AUDIT-FILE-2026-3304-02",
        "fileId": "FILE-2026-3304",
        "timestamp": "2026-01-28T14:15:00.000Z",
        "dateFormatted": "28 Jan 2026",
        "timeFormatted": "14:15",
        "officer": "Shri Pradip Dave",
        "action": "STAGE_ADVANCE",
        "remark": "Docket moved to Document Scrutiny table. Cross-referencing revenue title and Fire NOC.",
        "prevHash": "sha256:0a4f89b1c720e3d5",
        "hash": "sha256:4b91f0c2e819a374"
      }
    ]
  },
  {
    "id": "FILE-2026-2103",
    "fileNumber": "AICTE/SWRO/2026-27/1-8930340",
    "instituteName": "R.V. College of Engineering (RVCE)",
    "location": "Mysore Road, Bengaluru, Karnataka",
    "region": "SWRO",
    "intake": 840,
    "complianceScore": 100,
    "currentStageId": 5,
    "daysElapsed": 42,
    "totalSlaDays": 45,
    "status": "ON_TRACK",
    "statusText": "Autonomous Council Order",
    "photoUrl": CAMPUS_PLACEHOLDER_SVG,
    "labPhotoUrl": "https://images.unsplash.com/photo-1517694712202-14dd9538aa97?auto=format&fit=crop&w=1200&q=85",
    "blueprintUrl": BLUEPRINT_PLACEHOLDER_SVG,
    "geoCoords": "12.923° N, 77.498° E",
    "labDetails": "Centre of Excellence in E-Mobility & Cognitive Computing",
    "officer": {
      "name": "Dr. C. R. Girish",
      "role": "Regional Director",
      "avatar": "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=150&q=80"
    },
    "metrics": {
      "carpetArea": {
        "verified": 14800,
        "required": 8400,
        "unit": "sq.m",
        "ok": true
      },
      "fsr": {
        "actual": "1:11.7",
        "required": "1:15",
        "ok": true
      },
      "fireNoc": {
        "validUntil": "25 Jan 2028",
        "ok": true,
        "label": "BBMP Fire Safety Certificate"
      },
      "landTitle": {
        "registered": true,
        "ok": true,
        "label": "Rashtreeya Sikshana Samithi Trust"
      },
      "jointFdr": {
        "amount": "₹2.00 Crore",
        "ok": true,
        "label": "Canara Bank Joint FDR"
      }
    },
    "statusColor": "pine",
    "stampLabel": "COUNCIL ORDER",
    "auditTrail": [
      {
        "id": "AUDIT-FILE-2026-2103-01",
        "fileId": "FILE-2026-2103",
        "timestamp": "2026-01-20T09:30:00.000Z",
        "dateFormatted": "20 Jan 2026",
        "timeFormatted": "09:30",
        "officer": "Dr. C. R. Girish",
        "action": "APPLICATION_INWARD",
        "remark": "Application inward received, processing fees verified, uploaded affidavit registered.",
        "prevHash": "GENESIS_BLOCK_AICTE_REGULATORY_ROOT",
        "hash": "sha256:0a4f89b1c720e3d5"
      },
      {
        "id": "AUDIT-FILE-2026-2103-02",
        "fileId": "FILE-2026-2103",
        "timestamp": "2026-01-28T14:15:00.000Z",
        "dateFormatted": "28 Jan 2026",
        "timeFormatted": "14:15",
        "officer": "Dr. C. R. Girish",
        "action": "STAGE_ADVANCE",
        "remark": "Docket moved to Document Scrutiny table. Cross-referencing revenue title and Fire NOC.",
        "prevHash": "sha256:0a4f89b1c720e3d5",
        "hash": "sha256:4b91f0c2e819a374"
      }
    ]
  },
  {
    "id": "FILE-2026-2104",
    "fileNumber": "AICTE/SWRO/2026-27/1-8930415",
    "instituteName": "College of Engineering, Trivandrum (CET)",
    "location": "Thiruvananthapuram, Kerala",
    "region": "SWRO",
    "intake": 720,
    "complianceScore": 100,
    "currentStageId": 5,
    "daysElapsed": 40,
    "totalSlaDays": 45,
    "status": "ON_TRACK",
    "statusText": "Council Order Issued",
    "photoUrl": CAMPUS_PLACEHOLDER_SVG,
    "labPhotoUrl": "https://images.unsplash.com/photo-1581092795360-fd1ca04f0952?auto=format&fit=crop&w=1200&q=85",
    "blueprintUrl": BLUEPRINT_PLACEHOLDER_SVG,
    "geoCoords": "8.546° N, 76.906° E",
    "labDetails": "Advanced Fluid Mechanics & Hydraulics Research Rig",
    "officer": {
      "name": "Smt. Shailaja Menon",
      "role": "Accounts Officer",
      "avatar": "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=150&q=80"
    },
    "metrics": {
      "carpetArea": {
        "verified": 12500,
        "required": 7200,
        "unit": "sq.m",
        "ok": true
      },
      "fsr": {
        "actual": "1:12.3",
        "required": "1:15",
        "ok": true
      },
      "fireNoc": {
        "validUntil": "14 Nov 2027",
        "ok": true,
        "label": "Kerala Fire & Rescue Force"
      },
      "landTitle": {
        "registered": true,
        "ok": true,
        "label": "Govt of Kerala Autonomous Freehold"
      },
      "jointFdr": {
        "amount": "₹1.50 Crore",
        "ok": true,
        "label": "State Bank of India FDR"
      }
    },
    "statusColor": "pine",
    "stampLabel": "COUNCIL ORDER",
    "auditTrail": [
      {
        "id": "AUDIT-FILE-2026-2104-01",
        "fileId": "FILE-2026-2104",
        "timestamp": "2026-01-20T09:30:00.000Z",
        "dateFormatted": "20 Jan 2026",
        "timeFormatted": "09:30",
        "officer": "Smt. Shailaja Menon",
        "action": "APPLICATION_INWARD",
        "remark": "Application inward received, processing fees verified, uploaded affidavit registered.",
        "prevHash": "GENESIS_BLOCK_AICTE_REGULATORY_ROOT",
        "hash": "sha256:0a4f89b1c720e3d5"
      },
      {
        "id": "AUDIT-FILE-2026-2104-02",
        "fileId": "FILE-2026-2104",
        "timestamp": "2026-01-28T14:15:00.000Z",
        "dateFormatted": "28 Jan 2026",
        "timeFormatted": "14:15",
        "officer": "Smt. Shailaja Menon",
        "action": "STAGE_ADVANCE",
        "remark": "Docket moved to Document Scrutiny table. Cross-referencing revenue title and Fire NOC.",
        "prevHash": "sha256:0a4f89b1c720e3d5",
        "hash": "sha256:4b91f0c2e819a374"
      }
    ]
  },
  {
    "id": "FILE-2026-2105",
    "fileNumber": "AICTE/SWRO/2026-27/1-8930522",
    "instituteName": "National Institute of Engineering (NIE)",
    "location": "Manandavadi Road, Mysuru, Karnataka",
    "region": "SWRO",
    "intake": 540,
    "complianceScore": 100,
    "currentStageId": 3,
    "daysElapsed": 25,
    "totalSlaDays": 35,
    "status": "ON_TRACK",
    "statusText": "Physical Inspection Cleared",
    "photoUrl": CAMPUS_PLACEHOLDER_SVG,
    "labPhotoUrl": "https://images.unsplash.com/photo-1581092335397-9583fe92d232?auto=format&fit=crop&w=1200&q=85",
    "blueprintUrl": BLUEPRINT_PLACEHOLDER_SVG,
    "geoCoords": "12.287° N, 76.643° E",
    "labDetails": "Renewable Solar Thermal & Photovoltaic Testing Lab",
    "officer": {
      "name": "Dr. C. R. Girish",
      "role": "Regional Director",
      "avatar": "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=150&q=80"
    },
    "metrics": {
      "carpetArea": {
        "verified": 8600,
        "required": 5400,
        "unit": "sq.m",
        "ok": true
      },
      "fsr": {
        "actual": "1:13.5",
        "required": "1:15",
        "ok": true
      },
      "fireNoc": {
        "validUntil": "10 Oct 2026",
        "ok": true,
        "label": "Mysuru Fire Services Cleared"
      },
      "landTitle": {
        "registered": true,
        "ok": true,
        "label": "NIE Society Freehold (18 Acres)"
      },
      "jointFdr": {
        "amount": "₹1.00 Crore",
        "ok": true,
        "label": "Canara Bank Joint FDR"
      }
    },
    "statusColor": "pine",
    "stampLabel": "IN SCRUTINY",
    "auditTrail": [
      {
        "id": "AUDIT-FILE-2026-2105-01",
        "fileId": "FILE-2026-2105",
        "timestamp": "2026-01-20T09:30:00.000Z",
        "dateFormatted": "20 Jan 2026",
        "timeFormatted": "09:30",
        "officer": "Dr. C. R. Girish",
        "action": "APPLICATION_INWARD",
        "remark": "Application inward received, processing fees verified, uploaded affidavit registered.",
        "prevHash": "GENESIS_BLOCK_AICTE_REGULATORY_ROOT",
        "hash": "sha256:0a4f89b1c720e3d5"
      },
      {
        "id": "AUDIT-FILE-2026-2105-02",
        "fileId": "FILE-2026-2105",
        "timestamp": "2026-01-28T14:15:00.000Z",
        "dateFormatted": "28 Jan 2026",
        "timeFormatted": "14:15",
        "officer": "Dr. C. R. Girish",
        "action": "STAGE_ADVANCE",
        "remark": "Docket moved to Document Scrutiny table. Cross-referencing revenue title and Fire NOC.",
        "prevHash": "sha256:0a4f89b1c720e3d5",
        "hash": "sha256:4b91f0c2e819a374"
      }
    ]
  }
];
